#ifndef __LED_H
#define __LED_H
#include "sys.h"
void ledInit(void);//��ʼ��
#endif
