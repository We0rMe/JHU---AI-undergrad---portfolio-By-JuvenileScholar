#include "delay.h"
#include "stm32f10x.h"

void delayInit()
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
    SysTick_Config(SystemCoreClock/1000/8);
}


void delay_ms_normal(u32 nms)
{
    while(nms--)
    {
        __NOP();
    }
}


void delay_IRQ(u32 nms)
{
    uint32_t start_tick = systemTimeInMS;
    uint32_t wait_ticks = nms;
    
    while((systemTimeInMS - start_tick) < wait_ticks);
}

void SysTick_Handler(void)
{
    systemTimeInMS++;
}
