#include "stm32f10x.h"
#include "led.h"
#include "delay.h"

volatile u32 systemTimeInMS = 0;

int main(void)
{
    len_Init();
    delayInit();
    
    while(1)
    {
        GPIO_ResetBits(GPIOB, GPIO_Pin_5);
        GPIO_SetBits(GPIOE, GPIO_Pin_5);
        //delay_ms_normal(500);
        delay_IRQ(4000);
        
        GPIO_SetBits(GPIOB, GPIO_Pin_5);
        GPIO_ResetBits(GPIOE, GPIO_Pin_5);
        //delay_ms_normal(500);
        delay_IRQ(4000);
    }
    return 0;
}
