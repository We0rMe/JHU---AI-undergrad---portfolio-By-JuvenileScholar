#ifndef __SYS_H
#define __SYS_H
#include "stm32f10x.h"
//STM32F10X_HD
//#include "stm32f4xx.h"
//STM32F40_41xxx
extern volatile u32 systemTimeInMS;

#endif
