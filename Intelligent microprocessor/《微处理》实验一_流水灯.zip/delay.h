#ifndef __DELAY_H
#define __DELAY_H
#include "sys.h"

void delayInit(void);
void delay_ms_normal(u32 nms);
void delay_ms(u16 nms);
void delay_IRQ(u32 nms);
void delay_set(u32 nms);

#endif





























