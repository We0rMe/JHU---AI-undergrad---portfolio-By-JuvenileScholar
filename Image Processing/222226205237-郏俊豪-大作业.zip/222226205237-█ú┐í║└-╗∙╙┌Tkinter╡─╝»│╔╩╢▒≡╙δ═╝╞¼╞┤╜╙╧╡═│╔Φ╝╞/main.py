from tkinter import *
import cv2
from pyzbar.pyzbar import decode
from tkinter import Tk, filedialog
import pyzbar.pyzbar as pyzbar
import numpy as np
import imutils
import tkinter as tk
import pytesseract
import sqlite3
from PIL import Image
from tkinter import messagebox
import os

                                 # 二维码识别
def decode_qr(image):
    # 使用ZBar库解码二维码和条形码
    barcodes = decode(image)
    if barcodes:
        w = 0   # 多个结果的换行输出
        for barcode in barcodes:
            # 提取二维码信息并输出结果
            qr_data = barcode.data.decode("utf-8")
            print("QR Code Data:", qr_data)
            Label(root1, text="识别地址："+qr_data, bg='white', fg='red', font=('宋体', 10)).place(x=0, y=300+w)
            w = w + 20

def bendi1():
    # 从文件中读取图像
    image_path = filedialog.askopenfilename()  # 打开文件选择对话框

    if not image_path:
        # print("没有选择文件，退出程序。")
        messagebox.showerror(title='提示', message='无法读取图片，请重新尝试。')
        return
    image = cv2.imread(image_path)
    if image is None:
        # print(f"无法读取图片：{image_path}")
        messagebox.showerror(title='提示', message='无法读取图片，请重新尝试。')
        return

    # 解码二维码
    decode_qr(image)

def decodeDisplay(image):
    barcodes = pyzbar.decode(image)
    rects_list = []
    polygon_points_list = []
    QR_info = []

    sit = 0
    for barcode in barcodes:
        (x, y, w, h) = barcode.rect
        rects_list.append((x, y, w, h))
        cv2.rectangle(image, (x, y), (x+w, y+h), (0, 0, 255), 2)
        polygon_points = barcode.polygon

        extract_polygon_points = np.zeros((4, 2), dtype=int)
        for idx, points in enumerate(polygon_points):
            point_x, point_y = points
            extract_polygon_points[idx] = [point_x, point_y]

        extract_polygon_points = extract_polygon_points.reshape((-1, 1, 2))
        polygon_points_list.append(extract_polygon_points)

        cv2.polylines(image, [extract_polygon_points], isClosed=True, color=(255, 0 ,255), thickness=2, lineType=cv2.LINE_AA)

        barcodeData = barcode.data.decode("utf-8")
        barcodeType = barcode.type

        text = "{} ({})".format(barcodeData, barcodeType)
        QR_info.append(text)
        cv2.putText(image, text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, .5, (0, 0, 125), 2)

        print("barcode：{}".format(barcodeData))
        Label(root1, text="识别地址：" + barcodeData, bg='white', fg='red', font=('宋体', 10)).place(x=0, y=300 + sit)
        sit = sit + 20
    return image, rects_list, polygon_points_list, QR_info

def saoma():
    # 初始化摄像头de
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        messagebox.showerror("错误", "摄像头未打开，请检查摄像头连接和权限设置。")

    while True:
        ret, frame = cap.read()

        # 预处理图像
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # 转换为灰度图像
        im, rects_list, polygon_points_list, QR_info = decodeDisplay(gray)

        for data in zip(rects_list, polygon_points_list, QR_info):
            x, y, w, h = data[0]
            polygon_points = data[1]
            text = data[2]
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 2)
            cv2.polylines(frame, [polygon_points], isClosed=True, color=(255, 0, 255), thickness=2, lineType=cv2.LINE_AA)
            cv2.putText(frame, text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, .5, (0, 0, 125), 2)

        # 如果按下'q'键，退出循环
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# 二维码识别
def table1():
    global root1
    root1 = Tk()
    root1.geometry('400x400')
    root1.title('二维码识别')
    Label(root1, text='二维码识别', bg='white', fg='green', font=('宋体', 20)).pack(side=TOP, fill='x')

    Button(root1, text="本地图片", command=bendi1).place(relx=0.5, rely=0.3, width=200, anchor=CENTER)
    Button(root1, text="实时扫码", command=saoma).place(relx=0.5, rely=0.6, width=200, anchor=CENTER)



                                 # 车牌识别
def Cardect(img, w):
    pytesseract.pytesseract.tesseract_cmd = r'D:\Tesseract-OCR\tesseract.exe'

    img = cv2.resize(img, (600, 400))

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 13 , 15, 15)

    edged = cv2.Canny(gray, 30, 200)
    contours = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = imutils.grab_contours(contours)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]
    screenCnt = None

    for c in contours:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.018 * peri, True)

        if len(approx) == 4:
            screenCnt = approx
            break

    if screenCnt is None:
        detected = 0
        print("未检测到车牌信息")
        if w == 1:
            w = 0
            messagebox.showerror(title='提示', message='未检测到车牌信息')
    else:
        detected = 1

    if detected == 1:
        cv2.drawContours(img, [screenCnt], -1, (0, 0, 255), 3)

    text = None
    if screenCnt is not None:
        mask = np.zeros(gray.shape, np.uint8)
        new_image = cv2.drawContours(mask, [screenCnt], 0, 255, -1)
        new_image = cv2.bitwise_and(img, img, mask=mask)

        (x, y) = np.where(mask == 255)
        (topx, topy) = (np.min(x), np.min(y))
        (bottomx, bottomy) = (np.max(x), np.max(y))
        Cropped = gray[topx:bottomx + 1, topy:bottomy +1]

        text = pytesseract.image_to_string(Cropped, config='--psm 11')
        print("车牌号码是：", text)
        Label(root2, text="车牌号为：" + text, bg='white', fg='red', font=('宋体', 10)).place(x=140, y=300)
        img = cv2.resize(img, (500, 300))
        Cropped = cv2.resize(Cropped,(400, 200))
        # cv2.imshow('car',img)
        # cv2.imshow("Cropped", Cropped)    # 显示截取的车牌区域
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    else:
        print("没有找到车牌轮廓，无法继续处理")
        if w == 1:
           messagebox.showerror(title='提示', message='未找到车牌轮廓，无法继续处理')
    return img, text

def bendi2():
    # 从文件中读取图像
    image_path = filedialog.askopenfilename()  # 打开文件选择对话框

    if not image_path:
        # print("没有选择文件，退出程序。")
        messagebox.showerror(title='提示', message='没有选择文件，请重新尝试。')
        return
    image = cv2.imread(image_path)
    if image is None:
        # print(f"无法读取图片：{image_path}")
        messagebox.showerror(title='提示', message='无法读取图片，请重新尝试。')
        return

    Cardect(image, 1)


def shisi():
    video_path = filedialog.askopenfilename()  # 打开文件选择对话框
    cap = cv2.VideoCapture(video_path)
    plate_list = []  # 创建一个空列表来保存检测到的车牌信息

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # cv2.imshow('License Plate Detection', frame)
        Cardect(frame, 0)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    # 车牌识别
def table2():
    global root2
    root2 = Tk()
    root2.geometry('400x400')
    root2.title('车牌识别')

    Label(root2, text='车牌识别', bg='white', fg='green', font=('宋体', 20)).pack(side=TOP, fill='x')
    Button(root2, text="本地图片", command=bendi2).place(relx=0.5, rely=0.3, width=200, anchor=CENTER)
    Button(root2, text="视频检测", command=shisi).place(relx=0.5, rely=0.7, width=200, anchor=CENTER)



                                 # 人脸检测

def insertOrUpdate(id, name, age):
    conn = sqlite3.connect("FaceBase.db")
    sql = "SELECT * FROM people WHERE id = " + str(id)
    cursor = conn.execute(sql)
    isRecordExist = 0
    for row in cursor:
        isRecordExist = 1
    if (isRecordExist == 1):
        cmd = "UPDATE people SET name=" + str(name) + ",age=" + str(age) + " WHERE id = " + str(id)
    else:
        cmd = "INSERT INTO people (id, name, age) VALUES (" + id + "," + str(name) + "," + age + ")"
    print(cmd)
    conn.execute(cmd)
    conn.commit()
    conn.close()

# 遍历数据集
def getImageWithID(path):
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    faces = []
    IDs = []
    for imagePath in imagePaths:
        faceImg = Image.open(imagePath).convert('L');
        faceNP = np.array(faceImg, 'uint8')
        ID = int(os.path.split(imagePath)[-1].split('.')[1])
        faces.append(faceNP)
        IDs.append(ID)
        cv2.imshow("Training", faceNP)
        cv2.waitKey(10)
    return np.array(IDs), faces

def datasetCreator(id_entry, name_entry, age_entry):

    # 待采集的人脸对应的编号
    id = id_entry.get()  # 通过get()方法获取
    name = name_entry.get()
    age = age_entry.get()

    # 检查是否有任意一个输入框为空
    if not id or not name or not age:
        # 如果有空，则弹出错误提示
        messagebox.showerror("错误", "不能有输入为空")
    else:
        name = "'" + name + "'"
        # 导入openCV自带的人脸检测配置文件
        face_cascade = cv2.CascadeClassifier(r'C:\Users\86178\AppData\Roaming\Python\Python39\site-packages\cv2\data\haarcascade_frontalface_default.xml')
        # 启动电脑的摄像头
        cam = cv2.VideoCapture(0)

        insertOrUpdate(id, name, age)
        # 人脸样本编号
        sampleNum = 0
        while True:
            ret, img = cam.read()
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.1, 7)
            for (x, y, w, h) in faces:
                sampleNum = sampleNum + 1
                # 将检测到的人脸保存至dataSet/User.{id}.{sampleNum}.jpg
                # 当id为1时保存后的文件名如:User.1.1.jpg
                cv2.imwrite('dataSet/User.' + str(id) + '.' + str(sampleNum) + '.jpg', gray[y:y + h, x:x + w])
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
                # 每隔0.1秒采集一次人脸图像
                cv2.waitKey(100)
            cv2.imshow("Face", img)
            cv2.waitKey(1)
            # 当采集了相应人脸样本后停止采集
            if (sampleNum >= 40):
                break
        # 关闭摄像头
        cam.release()
        # 关闭摄像头显示窗口
        cv2.destroyAllWindows()

        # 训练

        # 创建LBP人脸识别器
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        path = 'dataSet'

        Ids, faces = getImageWithID(path)
        # 训练
        recognizer.train(faces, Ids)
        # 保存训练结果
        recognizer.save('recognizer/trainningData.yml')
        cv2.destroyAllWindows()


def dataSet(id_entry, name_entry, age_entry):
    datasetCreator(id_entry, name_entry, age_entry)

def bendi3():

    # 从文件中读取图像

    image_path = filedialog.askopenfilename()  # 打开文件选择对话框

    if not image_path:
        # print("没有选择文件，退出程序。")

        messagebox.showerror(title='提示', message='没有选择文件，请重新尝试。')

        return

    img = cv2.imread(image_path)

    if img is None:
        # print(f"无法读取图片：{image_path}")

        messagebox.showerror(title='提示', message='无法读取图片，请重新尝试。')

        return

    # 检测函数

    gary = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    face_detect = cv2.CascadeClassifier(r'C:\Users\86178\AppData\Roaming\Python\Python39\site-packages\cv2\data\haarcascade_frontalface_default.xml')

    face = face_detect.detectMultiScale(gary)

    for x, y, w, h in face:
        cv2.rectangle(img, (x, y), (x + w, y + h), color=(0, 0, 255), thickness=2)

        cv2.imshow('result', img)

    # 等待

    while True:
        if ord('q') == cv2.waitKey(0):
            break

    # 释放内存
    cv2.destroyAllWindows()

def getProfile(id):
    conn = sqlite3.connect("FaceBase.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM people WHERE id = ?", (id,))
    profile = cursor.fetchone()
    conn.close()
    return profile

def detector():
    # 导入openCV自带的人脸检测配置文件
    face_cascade = cv2.CascadeClassifier('C:/Users/86178/AppData/Roaming/Python/Python39/site-packages/cv2/data/haarcascade_frontalface_default.xml')
    cam = cv2.VideoCapture(0)

    # 创建LBP人脸识别器
    rec = cv2.face.LBPHFaceRecognizer_create()

    # 加载训练结果至人脸识别器
    rec.read('recognizer/trainningData.yml')


    # 初始化字体
    font = cv2.FONT_HERSHEY_SIMPLEX

    while True:
        ret, img = cam.read()
        if not ret:
            break
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            id_, conf = rec.predict(gray[y:y + h, x:x + w])
            profile = getProfile(id_)
            if profile is not None:
                # 显示检测到的人脸对应的人名
                cv2.putText(img, f'Name: {profile[1]}', (x, y + h + 20), font, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
                cv2.putText(img, f'Age: {profile[2]}', (x, y + h + 40), font, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
            else:
                cv2.putText(img, 'Unknown', (x, y + h + 40), font, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

        cv2.imshow("Face", img)
        # 按Q键退出识别程序
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cam.release()
    cv2.destroyAllWindows()

# 人脸检测
def table3():
    root3 = tk.Tk()
    root3.geometry('400x400')
    root3.title('人脸检测与识别')

    # 标题
    Label(root3, text='人脸检测与识别', bg='white', fg='green', font=('宋体', 20)).place(relx=0.5, rely=0.1, anchor='center', width=200)

    # 编号标签和输入框
    Label(root3, text="编号：").place(relx=0.1, rely=0.25, anchor='w')
    id_entry = Entry(root3)
    id_entry.place(relx=0.3, rely=0.25, relwidth=0.6, anchor='w')

    # 名字标签和输入框
    Label(root3, text="名字：").place(relx=0.1, rely=0.35, anchor='w')
    name_entry = Entry(root3)
    name_entry.place(relx=0.3, rely=0.35, relwidth=0.6, anchor='w')

    # 年纪标签和输入框
    Label(root3, text="年纪：").place(relx=0.1, rely=0.45, anchor='w')
    age_entry = Entry(root3)
    age_entry.place(relx=0.3, rely=0.45, relwidth=0.6, anchor='w')

    # 人脸录入按钮
    Button(root3, text="人脸录入", command=lambda: dataSet(id_entry, name_entry, age_entry)).place(relx=0.5, rely=0.6, width=100, height=30, anchor='center')

    # 本地图片检测按钮
    Button(root3, text="本地图片检测", command=bendi3).place(relx=0.5, rely=0.7, width=100, height=30, anchor='center')

    # 实时检测按钮
    Button(root3, text="实时人脸识别", command=detector).place(relx=0.5, rely=0.8, width=100, height=30, anchor='center')

    root3.mainloop()




                          # 图像拼接

# 柱面投影拼接图像

def save_image(image, filename):
    img = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    img.save(filename)

def And():
    # 选择两幅图像
    file_paths = filedialog.askopenfilenames(title="选择两幅图像", filetypes=[("图像文件", "*.jpg;*.png;*.bmp;*.gif")])
    if len(file_paths) < 2:
        # print("请选择两幅图像")
        messagebox.showerror(title='提示', message='请至少选择两幅图像！')
        return

    if len(file_paths) == 3:
        imageL = cv2.imread(file_paths[0])
        imageM = cv2.imread(file_paths[1])
        imageR = cv2.imread(file_paths[2])

        # 检查图像是否读取成功
        if imageL is None or imageR is None:
             # print("无法读取图像")
             messagebox.showerror(title='提示', message='无法读取图像，请重新尝试。')
             return

        images = [imageL, imageM, imageR]

    elif len(file_paths) ==2:
            imageL = cv2.imread(file_paths[0])
            imageR = cv2.imread(file_paths[1])

            # 检查图像是否读取成功
            if imageL is None or imageR is None:
                # print("无法读取图像")
                messagebox.showerror(title='提示', message='无法读取图像，请重新尝试。')
                return

            images = [imageL, imageR]

    stitcher = cv2.createStitcher() if imutils.is_cv3() else cv2.Stitcher_create()
    (status, stitched) = stitcher.stitch(images)

    if status == 0:
        stitched = cv2.copyMakeBorder(stitched, 2, 2, 2, 2,
                                      cv2.BORDER_CONSTANT, (0, 0, 0))
        gray = cv2.cvtColor(stitched, cv2.COLOR_BGR2GRAY)
        thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY)[1]
        cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL,
                                cv2.CHAIN_APPROX_SIMPLE)
        cnts = imutils.grab_contours(cnts)
        c = max(cnts, key=cv2.contourArea)
        mask = np.zeros(thresh.shape, dtype="uint8")
        (x, y, w, h) = cv2.boundingRect(c)
        cv2.rectangle(mask, (x, y), (x + w, y + h), 255, -1)
        minRect = mask.copy()
        sub = mask.copy()
        while cv2.countNonZero(sub) > 0:
            minRect = cv2.erode(minRect, None)
            sub = cv2.subtract(minRect, thresh)
        cnts = cv2.findContours(minRect.copy(), cv2.RETR_EXTERNAL,
                                cv2.CHAIN_APPROX_SIMPLE)
        cnts = imutils.grab_contours(cnts)
        c = max(cnts, key=cv2.contourArea)
        (x, y, w, h) = cv2.boundingRect(c)
        stitched = stitched[y:y + h, x:x + w]


    # 无相似点
    else:
        print("[INFO] image stitching failed ({})".format(status))

    # 保存到AndPic文件夹中
    save_dir = "AndPic"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    save_image(stitched, os.path.join(save_dir, "result.jpg"))
    # print("拼接完成，图像已保存到AndPic文件夹中")
    messagebox.showinfo("任务完成", "拼接完成，图像已保存到AndPic文件夹中")

    # 显示原图像和合并后图像
    # cv2.imshow('left', imageL)
    # cv2.imshow('right', imageR)
    cv2.imshow('result', stitched)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def table4():
    global root4
    root4 = Tk()
    root4.geometry('400x400')
    root4.title('图像拼接')
    Label(root4, text='图像拼接', bg='white', fg='green', font=('宋体', 20)).pack(side=TOP, fill='x')

    Button(root4, text="选择拼接的图像", command=And).place(relx=0.5, rely=0.5, width=200, anchor=CENTER)



root = tk.Tk()
root.geometry('400x400')
root.title('BigWork')

Label(root, text='智能图像处理大作业', bg='white', fg='green', font=('宋体', 20)).pack(side=TOP, fill='x')

Button(root, text="二维码识别", command=lambda: table1()).place(relx=0.5, rely=0.2, width=200, anchor=CENTER)
Button(root, text="车牌识别", command=lambda: table2()).place(relx=0.5, rely=0.4, width=200, anchor=CENTER)
Button(root, text="人脸检测与识别", command=lambda: table3()).place(relx=0.5, rely=0.6, width=200, anchor=CENTER)
Button(root, text="图像拼接", command=lambda: table4()).place(relx=0.5, rely=0.8, width=200, anchor=CENTER)

root.mainloop()