import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
import torch
from torch import nn
from torch.optim import Adam
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import classification_report, confusion_matrix
import os
from tqdm import tqdm
tqdm.pandas()
from collections import Counter

nltk.data.path.append('C:\\Users\\86178\\AppData\\Roaming\\nltk_data')
stopwords = set(stopwords.words('english'))
data = pd.read_csv(r'F:\IMDB Dataset.csv\IMDB Dataset.csv')
data.head()

def transform_label(label):
    return 1 if label == 'positive' else 0

data['label'] = data['sentiment'].progress_apply(transform_label)

data['token_length'] = data.review.progress_apply(lambda x: len(x.split()))

data_pos = data[data['label'] == 1]
data_neg = data[data['label'] == 0]

plt.figure(figsize=(5, 8))
sns.displot(data=data_pos, x='token_length', color='darkorange')
plt.title('Positive Length Distribution')
plt.xlabel('Length')
plt.show()
plt.figure(figsize=(5, 8))
sns.displot(data_neg, x='token_length', color='darkblue')
plt.title('Negtive Length Distribution')
plt.xlabel('Length')
plt.show()

print('Positive')
print(data_pos[data_pos['token_length'] == data_pos['token_length'].min()]['review'].item())
print()
print('Negative')
print(data_neg[data_neg['token_length'] == data_neg['token_length'].min()]['review'].item())

def rm_link(text):
    return re.sub(r'https?://\S+|www\.\S+', '', text)

def rm_punct2(text):
    return re.sub(r'[\"\#\$\%\&\'\(\)\*\+\/\:\;\<\=\>\@\[\\\]\^\_\`\{\|\}\~]', ' ', text)

def rm_html(text):
    return re.sub(r'<[^>]+>', '', text)

def space_bt_punct(text):
    pattern = r'([.,!?-])'
    s = re.sub(pattern, r' \1 ', text)
    s = re.sub(r'\s{2,}', ' ', s)
    return s

def rm_number(text):
    return re.sub(r'\d+', '', text)

def rm_whitespaces(text):
    return re.sub(r' +', ' ', text)

def rm_nonascii(text):
    return re.sub(r'[^\x00-\x7f]', r'', text)

def rm_emoji(text):
    emojis = re.compile(
        '['
        u'\U0001F600-\U0001F64F'  # 表情
        u'\U0001F300-\U0001F5FF'
        u'\U0001F680-\U0001F6FF'
        u'\U0001F1E0-\U0001F1FF'
        u'\U00002702-\U000027B0'
        u'\U000024C2-\U0001F251'
        ']+',
        flags=re.UNICODE
    )
    return emojis.sub(r'', text)

def spell_correction(text):
    return re.sub(r'(.)\1+', r'\1\1', text)

def clean_pipeline(text):
    no_link = rm_link(text)
    no_html = rm_html(no_link)
    space_punct = space_bt_punct(no_html)
    no_punct = rm_punct2(space_punct)
    no_number = rm_number(no_punct)
    no_whitespaces = rm_whitespaces(no_number)
    no_nonasci = rm_nonascii(no_whitespaces)
    no_emoji = rm_emoji(no_nonasci)
    spell_corrected = spell_correction(no_emoji)
    return spell_corrected

def tokenize(text):
    return word_tokenize(text)

def rm_stopwords(text):
    return [i for i in text if i not in stopwords]

def lemmatize(text):
    lemmatizer = WordNetLemmatizer()
    lemmas = [lemmatizer.lemmatize(t) for t in text]
    return rm_stopwords(lemmas)

def preprocess_pipeline(text):
    tokens = tokenize(text)
    no_stopwords = rm_stopwords(tokens)
    lemmas = lemmatize(no_stopwords)
    return ' '.join(lemmas)

data['clean'] = data['review'].progress_apply(clean_pipeline)
data['processed'] = data['clean'].progress_apply(preprocess_pipeline)
data.head()

data[['processed', 'label']].to_csv('E:/IMDB Dataset.csv/imdb_processed.csv', index=False, header=True)

data = pd.read_csv(r'F:\IMDB Dataset.csv\imdb_processed.csv')

for row in data[:2].iterrows():
    print(row[1]['processed'])
    print(f'Label: {row[1]["label"]}')
    print('\n')

reviews = data.processed.values
words = ' '.join(reviews)
words = words.split()
print(words[:10])

counter = Counter(words)
vocab = sorted(counter, key=counter.get, reverse=True)
int2word = dict(enumerate(vocab, 1))
int2word[0] = '<PAD>'
word2int = {word: id for id, word in int2word.items()}

reviews_enc = [[word2int[word] for word in review.split()] for review in tqdm(reviews)]

for i in range(10):
    print(reviews_enc[i][:5])

def pad_features(reviews, pad_id, seq_length=128):
    features = np.full((len(reviews), seq_length), pad_id, dtype=int)

    for i, row in enumerate(reviews):
        features[i, :len(row)] = np.array(row)[:seq_length]

    return features

seq_length = 256
features = pad_features(reviews_enc, pad_id=word2int['<PAD>'], seq_length=seq_length)

assert len(features) == len(reviews_enc)
assert len(features[0]) == seq_length
print(features[:10, :10])

labels = data.label.to_numpy()
print(labels)

train_size = .8     # 0.8全部数据用作训练
val_size = .5       # 一半测试集用作验证

split_id = int(len(features) * train_size)
train_x, remain_x = features[:split_id], features[split_id:]
train_y, remain_y = labels[:split_id], labels[split_id:]

split_val_id = int(len(remain_x) * val_size)
val_x, test_x = remain_x[:split_val_id], remain_x[split_val_id:]
val_y, test_y = remain_y[:split_val_id], remain_y[split_val_id:]


print('Feature Shapes:')
print('Train set: {}'.format(train_x.shape))
print('Validation set: {}'.format(val_x.shape))
print('Test set: {}'.format(test_x.shape))

print(len(train_y[train_y == 0]), len(train_y[train_y == 1]))
print(len(val_y[val_y == 0]), len(val_y[val_y == 1]))
print(len(test_y[test_y == 0]), len(test_y[test_y == 1]))

import matplotlib.pyplot as plt
train_0_count = len(train_y[train_y == 0])
train_1_count = len(train_y[train_y == 1])
val_0_count = len(val_y[val_y == 0])
val_1_count = len(val_y[val_y == 1])
test_0_count = len(test_y[test_y == 0])
test_1_count = len(test_y[test_y == 1])
bar_width = 0.2
index_train = np.arange(2)
index_val = [i + bar_width for i in index_train]
index_test = [i + bar_width * 2 for i in index_train]
plt.bar(index_train, [train_0_count, train_1_count], bar_width, label='Train set')
plt.bar(index_val, [val_0_count, val_1_count], bar_width, label='Validation set')
plt.bar(index_test, [test_0_count, test_1_count], bar_width, label='Test set')
for i in range(2):
    plt.text(index_train[i], train_0_count if i == 0 else train_1_count, train_0_count if i == 0 else train_1_count,
             ha='center', va='bottom')
    plt.text(index_val[i], val_0_count if i == 0 else val_1_count, val_0_count if i == 0 else val_1_count,
             ha='center', va='bottom')
    plt.text(index_test[i], test_0_count if i == 0 else test_1_count, test_0_count if i == 0 else test_1_count,
             ha='center', va='bottom')
plt.xlabel('Data Type')
plt.ylabel('Data Size')
plt.xticks([i + bar_width for i in index_train], ['0', '1'])
plt.legend()
plt.show()

batch_size = 128

trainset = TensorDataset(torch.from_numpy(train_x), torch.from_numpy(train_y))
validset = TensorDataset(torch.from_numpy(val_x), torch.from_numpy(val_y))
testset = TensorDataset(torch.from_numpy(test_x), torch.from_numpy(test_y))

trainloader = DataLoader(trainset, shuffle=True, batch_size=batch_size)
valloader = DataLoader(validset, shuffle=True, batch_size=batch_size)
testloader = DataLoader(testset, shuffle=True, batch_size=batch_size)

dataiter = iter(trainloader)
x, y = dataiter.__next__()

print('Sample batch size: ', x.size())
print('Sample batch input: \n', x)
print()
print('Sample label size: ', y.size())
print('Sample label input: \n', y)

class Swish(nn.Module):
    def forward(self, x):
        return x * torch.sigmoid(x)


x = torch.linspace(-10.0, 10.0, 100)
swish = Swish()
swish_out = swish(x)
relu_out = torch.relu(x)

plt.figure(figsize=(5, 5))
plt.title('Swish function')
plt.plot(x.numpy(), swish_out.numpy(), label='Swish')
plt.plot(x.numpy(), relu_out.numpy(), label='ReLU')
plt.legend();
plt.savefig(f"Swish.png", format="png", bbox_inches='tight', pad_inches=0.2)
plt.show()

class SelfAttention(nn.Module):
    def __init__(self, hidden_size):
        super(SelfAttention, self).__init__()
        self.hidden_size = hidden_size

        # 线性层
        self.W_q = nn.Linear(hidden_size, hidden_size)
        self.W_k = nn.Linear(hidden_size, hidden_size)
        self.W_v = nn.Linear(hidden_size, hidden_size)

        self.scale = torch.sqrt(torch.tensor(hidden_size, dtype=torch.float32))

    def forward(self, x):
        batch_size, seq_length, hidden_size = x.size()

        Q = self.W_q(x)
        K = self.W_k(x)
        V = self.W_v(x)

        attention_scores = torch.bmm(Q, K.transpose(1, 2)) / self.scale

        attention_weights = nn.Softmax(dim=-1)(attention_scores)

        # 加权求和
        attended_output = torch.bmm(attention_weights, V)

        return attended_output, attention_weights


class SentimentModel(nn.Module):
    def __init__(self, vocab_size, output_size, hidden_size=128, embedding_size=400, n_layers=2, dropout=0.2):
        super(SentimentModel, self).__init__()

        self.embedding = nn.Embedding(vocab_size, embedding_size)

        self.lstm = nn.LSTM(embedding_size, hidden_size, n_layers, dropout=dropout, batch_first=True)

        self.attention = SelfAttention(hidden_size)

        self.swish = Swish()

        self.dropout = nn.Dropout(0.5)

        self.fc = nn.Linear(hidden_size, output_size)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = x.long()

        x = self.embedding(x)

        o, _ = self.lstm(x)

        o, attention_weights = self.attention(o)

        o = o[:, -1, :]

        o = self.swish(o)

        o = self.dropout(o)
        o = self.fc(o)

        o = self.sigmoid(o)

        return o, attention_weights

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(device)

vocab_size = len(word2int)
output_size = 1
embedding_size = 256
hidden_size = 256
n_layers = 2
dropout=0.25

model = SentimentModel(vocab_size, output_size, hidden_size, embedding_size, n_layers, dropout)
print(model)

criterion = nn.BCELoss()
optim = Adam(model.parameters(), lr=0.001, weight_decay=1e-4)
grad_clip = 3
epochs = 10
print_every = 1
history = {
    'train_loss': [],
    'train_acc': [],
    'val_loss': [],
    'val_acc': [],
    'epochs': epochs
}
es_limit = 5

model = model.to(device)

epochloop = tqdm(range(epochs), position=0, desc='Training', leave=True)

es_trigger = 0
val_loss_min = torch.inf

for e in epochloop:

    model.train()

    train_loss = 0
    train_acc = 0

    for id, (feature, target) in enumerate(trainloader):
        epochloop.set_postfix_str(f'Training batch {id}/{len(trainloader)}')

        feature, target = feature.to(device), target.to(device)

        optim.zero_grad()

        out, u = model(feature)

        predicted = torch.tensor([1 if i == True else 0 for i in out > 0.5], device=device)
        equals = predicted == target
        acc = torch.mean(equals.type(torch.FloatTensor))
        train_acc += acc.item()

        loss = criterion(out.squeeze(), target.float())
        train_loss += loss.item()
        loss.backward()

        nn.utils.clip_grad_norm_(model.parameters(), grad_clip)

        optim.step()

        del feature, target, predicted

    history['train_loss'].append(train_loss / len(trainloader))
    history['train_acc'].append(train_acc / len(trainloader))

    model.eval()

    val_loss = 0
    val_acc = 0

    # 验证，停止梯度计算
    with torch.no_grad():
        for id, (feature, target) in enumerate(valloader):
            epochloop.set_postfix_str(f'Validation batch {id}/{len(valloader)}')

            feature, target = feature.to(device), target.to(device)

            out, u = model(feature)

            predicted = torch.tensor([1 if i == True else 0 for i in out > 0.5], device=device)
            equals = predicted == target
            acc = torch.mean(equals.type(torch.FloatTensor))
            val_acc += acc.item()

            loss = criterion(out.squeeze(), target.float())
            val_loss += loss.item()

            del feature, target, predicted

        history['val_loss'].append(val_loss / len(valloader))
        history['val_acc'].append(val_acc / len(valloader))

    model.train()

    epochloop.set_postfix_str(f'Val Loss: {val_loss / len(valloader):.3f} | Val Acc: {val_acc / len(valloader):.3f}')

    if (e + 1) % print_every == 0:
        epochloop.write(
            f'Epoch {e + 1}/{epochs} | Train Loss: {train_loss / len(trainloader):.3f} Train Acc: {train_acc / len(trainloader):.3f} | Val Loss: {val_loss / len(valloader):.3f} Val Acc: {val_acc / len(valloader):.3f}')
        epochloop.update()

    if val_loss / len(valloader) <= val_loss_min:
        torch.save(model.state_dict(), './sentiment_lstm.pt')
        val_loss_min = val_loss / len(valloader)
        es_trigger = 0
    else:
        epochloop.write(
            f'[WARNING] Validation loss did not improved ({val_loss_min:.3f} --> {val_loss / len(valloader):.3f})')
        es_trigger += 1

    if es_trigger >= es_limit:
        epochloop.write(f'Early stopped at Epoch-{e + 1}')
        history['epochs'] = e + 1
        break

plt.figure(figsize=(6, 8))
plt.plot(range(history['epochs']), history['train_acc'], label='Train Acc')
plt.plot(range(history['epochs']), history['val_acc'], label='Val Acc')
plt.legend()
plt.show()

plt.figure(figsize=(6, 8))
plt.plot(range(history['epochs']), history['train_loss'], label='Train Loss')
plt.plot(range(history['epochs']), history['val_loss'], label='Val Loss')
plt.legend()
plt.show()

import matplotlib.colors as mcolors

# 测试
model.eval()

test_loss = 0
test_acc = 0

all_target = []
all_predicted = []

testloop = tqdm(testloader, leave=True, desc='Inference')
with torch.no_grad():
    for feature, target in testloop:
        feature, target = feature.to(device), target.to(device)

        out, attention_weights = model(feature)

        predicted = torch.tensor([1 if i == True else 0 for i in out > 0.5], device=device)
        equals = predicted == target
        acc = torch.mean(equals.type(torch.FloatTensor))
        test_acc += acc.item()

        loss = criterion(out.squeeze(), target.float())
        test_loss += loss.item()

        all_target.extend(target.cpu().numpy())
        all_predicted.extend(predicted.cpu().numpy())

    if attention_weights is not None:
        attention_weights_np = attention_weights.cpu().numpy()
        plt.figure(figsize=(8, 6))
        sns.heatmap(attention_weights_np[0], cmap='YlGnBu', annot=False, fmt='.2f')
        plt.title('Attention Weights Distribution for a Sample')
        plt.xlabel('Sequence Position')
        plt.ylabel('Attention Weight')
        plt.show()

    print(f'Accuracy: {test_acc / len(testloader):.4f}, Loss: {test_loss / len(testloader):.4f}')

print(classification_report(all_predicted, all_target))
cm = confusion_matrix(all_predicted, all_target)
plt.figure(figsize=(5,5))
sns.heatmap(cm, annot=True, fmt='g')
plt.title('Confusion Matrix')
plt.show()

# 数据增强：同义词替换
from nltk.corpus import wordnet
data = pd.read_csv('E:/IMDB Dataset.csv/imdb_processed.csv')

reviews = data.processed.values
labels = data.label.values

print(len(reviews))
print(len(labels))

def get_synonyms(word):
    synonyms = []
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonym = lemma.name()
            if synonym!= word and synonym not in synonyms:
                synonyms.append(synonym)
    return synonyms

enhanced_reviews = []
enhanced_labels = []
for review in tqdm(reviews):
    review_words = review.split()
    enhanced_reviews.append(review)

    synonym_review_words = []
    for word in review_words:
        synonyms = get_synonyms(word)
        if synonyms:
            synonym_word = np.random.choice(synonyms)
            synonym_review_words.append(synonym_word)
        else:
            synonym_review_words.append(word)
    enhanced_review = " ".join(synonym_review_words)
    enhanced_reviews.append(enhanced_review)

for label in tqdm(labels):
    enhanced_labels.append(label)
    enhanced_labels.append(label)

print(len(enhanced_reviews))
print(len(enhanced_labels))