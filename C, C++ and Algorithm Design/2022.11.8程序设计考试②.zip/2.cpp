#include <iostream>
using namespace std;
int main()
{
   int a=0,b=0,t;
   cin>>a;
   t=a;
   while(a>0)
   {
       b=b+a%10;
       a/=10;
   }
   cout<<t<<":"<<b;
   return 0;
   
}
