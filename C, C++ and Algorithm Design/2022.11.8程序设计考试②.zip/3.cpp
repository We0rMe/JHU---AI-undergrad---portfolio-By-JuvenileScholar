#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    int a,b,t,c,d;
    cin>>a>>b;
    c=abs(a);
    d=abs(b);
    if(c>d)
      t=c;
    else
      t=d;
    if(a==0&&b==0)
      cout<<"Error";
    else
    {
      for(t;t>0;t--)
      {  if(a%t==0&&b%t==0)
            break;
      }
      cout<<"GCD("<<a<<","<<b<<")="<<t;
    }
}
