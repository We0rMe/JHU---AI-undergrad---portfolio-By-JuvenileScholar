#include <iostream>
using namespace std;
int main()
{
    int a,i,t;
    cin>>a;
    t=a;
    if(a!=1)
    {
    for(i=1;;i++)
    {   
        if(a%2!=0)
          a=3*a+1;
        else
          a=a/2;
        if(a==1)
          break;
    }
    cout<<"Count("<<t<<")="<<i;
    }
    else
       cout<<"Count("<<t<<")="<<0;
}
