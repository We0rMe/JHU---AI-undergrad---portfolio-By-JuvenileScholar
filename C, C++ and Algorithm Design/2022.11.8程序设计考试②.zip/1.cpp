#include <iostream>
using namespace std;
int main()
{
    int a,b,t,m,u=0;
    cin>>a>>b;
    if(a>b)
    { m=b;
      t=a;
 
    }
    else
    { m=a;
      t=b;

    }
    if(a==b)
    { cout<<right;
      cout.width(5);
      cout<<a;
    }
    else
    {
    for(int i=m;i<=t;i++)
    {      
            
            cout<<right;
            cout.width(5);
            cout<<i;
            u++;
            if(u==8)
            {
                cout<<endl;
                u=0;
            }
            
    }
    }
    return 0;
}
