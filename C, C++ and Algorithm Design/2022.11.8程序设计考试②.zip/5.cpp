#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    double a,b,T1,T2,x,y,t;
    cin>>a>>b;
    if(a>b)
    { t=a;
      a=b;
      b=t; }  
    T1=2*sin(a)/(a+1)-cos(2*a)*exp(-a);
    T2=2*sin(b)/(b+1)-cos(2*b)*exp(-b);
    if(T1*T2>=0)
      cout<<"Not found.";
    else 
    {x=(a+b)/2;
     
         do
         {
             x=(a+b)*0.5;
             y=(2*sin(x))/(x+1)-cos(2*x)*exp(-x);
             if(y==0)
              break;
             if(y>0&&T1<0)
                b=x;
             else if(y>0&&T1>0)
                     a=x;
                  else if(y<0&&T1<0)
                          a=x;
                       else if(y<0&&T1>0)
                              b=x;
         }
         while(b-a>1e-5);
         cout.precision(3);
         cout<<fixed;
         cout<<x;
    }

}
