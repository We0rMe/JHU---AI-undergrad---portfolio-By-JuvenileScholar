#include <iostream>
#include <math.h>
using namespace std;
//start
int i=0;
double X=0;
double Y=0;
class Point
{
  private:
    double x,y;
  public:
    Point(double a=0,double b=0)
    {
        x=a;
        y=b;
        X+=a;
        Y+=b;
        i++;
    }
    Point(Point const &w)
    {
        x=w.x;
        y=w.y;
        X+=w.x;
        Y+=w.y;
        i++;
    }
    void Show()
    {
        cout<<fixed;
        cout.precision(2);
        cout<<"("<<x<<","<<y<<")";
    }
    double DistanceTo(Point w)
    {
        double k;
        k=sqrt((x-w.x)*(x-w.x)+(y-w.y)*(y-w.y));
        return k;
    }
    void Move(double dx,double dy)
    {
        x+=dx;
        y+=dy;
    }
    ~Point()
    {
        X-=x;
        Y-=y;
        i--;
    }
    int GetCount()
    {
        return i;
    }
    static void ShowCenter()
    {
        if(i==0)
          cout<<"Count=0";
        else
          cout<<i<<" points, center=("<<X/i<<","<<Y/i<<")"<<endl;
    }
};
//end
int main()
{
	int i,k,count;
	double x,y;
	Point *q[20];
	cin>>k;
    cout<<fixed;
    cout.precision(2);
	count=k%10+10;			//��ĸ���
	for(i=0;i<count;i++)	//����������ɸ���
	{
		k=(25173*k+13849)%65536;
		x=(k-19447)*0.0001;
		k=(25173*k+13849)%65536;
		y=(k-19447)*0.0001;
		q[i]=new Point(x,y);
	}
	Point::ShowCenter();	//��ʾ�������
	cout<<"Distance="<<q[0]->DistanceTo(*q[1])<<endl;//��ʾǰ������֮��ľ���
	q[2]->Move(-1,-1);		//2#����x�����y������ƶ�-1����λ
	q[2]->Show();          	//��ʾ�ƶ���ĵ�
	for(i=0;i<count;i++)
		delete q[i];
    cout<<endl;
	Point::ShowCenter();	//��ʾ�������
	return 0;
}
