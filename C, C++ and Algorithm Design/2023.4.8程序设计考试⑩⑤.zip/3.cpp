#include <iostream>
#include <math.h>
using namespace std;
//start
class MyComplex
{
  private:
    double real,imag;
  public:
    MyComplex()
    {
        real=0;
        imag=0;
    }
    MyComplex(double a,double b=0)
    {
        real=a;
        imag=b;
    }
    void Show()
    {
        if(imag==0)
          cout<<real;
        else 
        { 
          cout<<fixed;
          cout.precision(3);
          if(imag>0)
            cout<<"("<<real<<"+"<<imag<<"i)";
          else
            cout<<"("<<real<<"-"<<fabs(imag)<<"i)";
        }
    }
    double Modulus()
    {
        return sqrt(real*real+imag*imag);
    }
    static MyComplex ADD(MyComplex a,MyComplex b)
    {
        MyComplex w(0,0);
        w.real=a.real+b.real;
        w.imag=a.imag+b.imag;
        return w;
    }
    static MyComplex SUB(MyComplex a,MyComplex b)
    {
        MyComplex w(0,0);
        w.real=a.real-b.real;
        w.imag=a.imag-b.imag;
        return w;
    }
    static MyComplex MUL(MyComplex a,MyComplex b)
    {
        MyComplex w(0,0);
        w.real=a.real*b.real-a.imag*b.imag;
        w.imag=a.imag*b.real+a.real*b.imag;
        return w;
    }
    static MyComplex DIV(MyComplex a,MyComplex b)
    {
        if(b.real==0&&b.imag==0)
        {  
            cout<<"Divided by 0."<<endl;
            return MyComplex(0,0);
        }
        else
        {   MyComplex w(0,0);
            w.real=(a.real*b.real+a.imag*b.imag)/(b.real*b.real+b.imag*b.imag);
            w.imag=(a.imag*b.real-a.real*b.imag)/(b.real*b.real+b.imag*b.imag);
            return w;
        }
    }
};
//end
int main()
{
	double a,b,c,d;
	cin>>a>>b>>c>>d;
	cout.precision(3);
	cout<<fixed;
	MyComplex x(a,b),y(c,d),z(0,0);
	cout<<"ADD : ";
	z=MyComplex::ADD(x,y);
	z.Show();
	cout<<" , Modulus="<<z.Modulus()<<endl;
	cout<<"SUB : ";
	z=MyComplex::SUB(x,y);
	z.Show();
	cout<<" , Modulus="<<z.Modulus()<<endl;
	cout<<"MUL : ";
	z=MyComplex::MUL(x,y);
	z.Show();
	cout<<" , Modulus="<<z.Modulus()<<endl;
	cout<<"DIV : ";
	z=MyComplex::DIV(x,y);
	z.Show();
	cout<<" , Modulus="<<z.Modulus()<<endl;
	return 0;
}
