#include <iostream>
#include <stdlib.h>
using namespace std;
//start
class MyClock
{
  private:
    int h,m,s;
  public:
    MyClock()
    {
        h=0;m=0;s=0;
    }
    MyClock(int a)
    {   if(a>0&&a<86399)
        {h=a/3600;
        m=(a%3600)/60;
        s=(a%3600)%60;}
        else
        {
            h=0;m=0;s=0;
        }
    }
    MyClock(int a,int b)
    {
        h=a;m=b;s=0;
    }
    MyClock(int a,int b,int c)
    {   if(a>=24||a<0||b>=60||b<0||c>=60||c<0)
        {
            h=0;m=0;s=0;
        }
        else
        {
          h=a;
          m=b;
          s=c;
        }
    }
    void Set(int a,int b,int c=0)
    {
        if(a<0||a>=86399)
           ;
        else
        {
            h=a;
            m=b;
            s=c;
        }
    }
    void Set(int a=0)
    {
        if(a<0||a>=86399)
        {
            h=0;m=0;s=0;
        }
        else
        {
            h=a/3600;
            m=(a%3600)/60;
            s=(a%3600)%60;
        }
    }
    void Show()
    {
        cout<<fixed;
        cout.precision(2);
        if(h<10)
          cout<<0;
        cout<<h<<":";
        if(m<10)
          cout<<0;
        cout<<m<<":";
        if(s<10)
          cout<<0;
        cout<<s;
    }
    static bool Equals(MyClock w,MyClock q)
    {
        if(w.h==q.h&&w.m==q.m&&w.s==q.s)
          return true;
        else
          return false;
    }
    void Move(int x)
    {
        s+=x;
        if(s>=60)
        {   m+=s/60;
            s-=s/60*60;
            
        }
        if(m>=60)
        {   
            h+=m/60;
            m-=m/60*60;
            
        }
        if(h>=24)
        {
            h-=24;
        }
    }
};
//end
int main()
{
	int a,b,c;
	cin>>a>>b>>c;
	MyClock ck1(a),ck2;
	cout<<"Clock 1:\n";
	ck1.Show();
	cout<<endl;
	ck1.Move(b);
	cout<<b<<" seconds later:\n";
	ck1.Show();
	cout<<endl;
	cout<<"Clock 2:\n";
	ck2.Set(a%24,b%60,c);
	ck2.Show();
	cout<<endl;
	if(MyClock::Equals(ck1,ck2))
		cout<<"======\n";
	else
		cout<<"xxxxxx\n"; 
}
