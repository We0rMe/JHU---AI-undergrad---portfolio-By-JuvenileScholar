#include <iostream>
using namespace std;
//start
class Test
{
  private:
    char w[200];
  public:
    Test(char* q)
    {
        int i;
        for(i=0;*(q+i)!='\0';i++)
           w[i]=*(q+i);
        w[i]='\0';
        cout<<w<<" come"<<endl;
    }
    Test(Test &e)
    {
        int i;
        for(i=0;e.w[i]!='\0';i++)
           w[i]=e.w[i];
        w[i]='\0';
        cout<<w<<" COME"<<endl;
    }
    void Show()
    {
        cout<<'('<<w<<')'<<endl;
    }
    ~Test()
    {
        cout<<w<<" go"<<endl;
    }
};
void fun(Test s)
{
    s.Show();
}
//end
int main()
{
	char x[51];
	cin>>x;
	cout<<"main start\n";
	Test t(x);
	fun(t);
	cout<<"main end\n";
}
