#include <iostream>
using namespace std;
//start
class Test
{
  private:
    char w[200];
  public:
    Test(char* a)
    {   int i;
        for(i=0;*(a+i)!='\0';i++)
           w[i]=*(a+i);
        w[i]='\0';
        cout<<w<<" come"<<endl;
    }
    void Show()
    {
        cout<<'('<<w<<')'<<endl;
    }
    ~Test()
    {
        cout<<w<<" go"<<endl;
    }
};
void fun(char* e)
{
    Test s(e);
    s.Show();
}
//end
int main()
{
	char x[51];
	cin>>x;
	cout<<"main start\n";
	fun(x);
	cout<<"main end\n";
}
