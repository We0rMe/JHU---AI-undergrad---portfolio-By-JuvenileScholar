#include <iostream>
using namespace std;
//start
class Test
{
  private:
    char w[200];
  public:
    Test(char* a)
    {
        int i;
        for(i=0;*(a+i)!='\0';i++)
           w[i]=*(a+i);
        w[i]='\0';
        cout<<w<<" come"<<endl;
    }
    void Show()
    {
        cout<<'('<<w<<')'<<endl;
    }
    ~Test()
    {
      cout<<w<<" go"<<endl;  
    }
};
Test* fun(char* t)
{
    Test* o=new Test(t);
    (*o).Show();
    return o;
}
//end
int main()
{
	char x[51];
	cin>>x;
	Test *q;
	cout<<"main start\n";
	q=fun(x);
	delete q;
	cout<<"main end\n";
}
