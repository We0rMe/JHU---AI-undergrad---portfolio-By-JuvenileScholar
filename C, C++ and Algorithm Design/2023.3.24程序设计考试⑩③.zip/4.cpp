#include <iostream>
using namespace std;
//start
class Test
{
  private:
    char w[200];
  public:
    Test(char* q)
    {
        int i=0;
        for(i;*(q+i)!='\0';i++)
          w[i]=*(q+i);
        w[i]='\0';
        cout<<w<<" come"<<endl;
    }
    Test(Test &t)
    {
       int i;
       for(i=0;t.w[i]!='\0';i++)
           w[i]=t.w[i];
        w[i]='\0';
        cout<<w<<" COME"<<endl;
    }
    void Show()
    {
        cout<<'('<<w<<')'<<endl;
    }
    ~Test()
    {
        cout<<w<<" go"<<endl;
    }
    int count()
    {
        int i;
        for(i=0;w[i]!='\0';i++)
           ;
        return i;
    }
};
Test x("Hello");
Test* fun(Test a)
{
    int n=a.count();
    char m[200];
    for(int i=0;i<n;i++)
       m[i]=(char)('A'+i);
    Test* l=new Test(m);
    (*l).Show();
    return l;
}
//end
int main()
{
	char x[51];
	Test *q;
	cin>>x;
	cout<<"main start\n";
	Test t(x);
	q=fun(t);
	delete q;
	cout<<"main end\n";
}
