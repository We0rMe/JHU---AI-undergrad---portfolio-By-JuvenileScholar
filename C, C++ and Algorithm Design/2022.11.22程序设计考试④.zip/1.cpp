#include <iostream>
using namespace std;
int main()
{
    int n,i;
    cin>>n;
    int s[n];
    for(i=1;i<=n;i++)
    {
        cin>>s[i-1];
    }
    for(i=0;i<n;i++)
    {
        if(s[i]%2!=0)
        {  
           cout<<s[i]<<" ";}
    }
    for(i=0;i<n;i++)
    {
        if(s[i]%2==0)
        {   
            cout<<s[i]<<" ";}
    }
}
