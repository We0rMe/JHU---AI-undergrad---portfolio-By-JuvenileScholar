#include <iostream>
using namespace std;
int main()
{
    int n,i,j;
    cin>>n;
    int o=n;
    int s[n],t[n];
    for(i=0;i<n;i++)
       cin>>s[i];
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(s[i]>=s[j])
            {
                o--;
            }
            t[i]=o;
        }
        o=n;
    }
    for(i=0;i<n;i++)
        cout<<t[i]+1<<" ";
}
