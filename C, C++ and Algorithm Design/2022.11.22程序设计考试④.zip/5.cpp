#include <iostream>
using namespace std;
int main()
{
    int n,m,i,j,o;
    cin>>n>>m;
    int s[n+1];
    for(i=1;i<=n;i++)
       s[i]=0;
    for(i=1;i<=m;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(j%i==0)
            {
               if(s[j]==0)
                  s[j]=1;
               else if(s[j]==1)
                       s[j]=0;
            }
        }
    }
    for(i=1;i<=n;i++)
    {
        if(s[i]==1)
           o++;
    }
    cout<<o;
}
