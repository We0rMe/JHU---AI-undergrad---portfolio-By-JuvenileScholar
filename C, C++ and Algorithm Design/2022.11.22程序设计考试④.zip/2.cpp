#include <iostream>
using namespace std;
int main()
{
    int n,i,j,o=0;
    cin>>n;
    int s[n];
    for(i=1;i<=n;i++)
    {
        cin>>s[i-1];
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(s[i]>=s[j])
               o=1;
        }
    }
    if(o==1)
       cout<<"No";
    else
       cout<<"Yes";
}
