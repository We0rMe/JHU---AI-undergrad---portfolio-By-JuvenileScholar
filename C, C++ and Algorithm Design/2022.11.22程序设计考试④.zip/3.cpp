#include <iostream>
using namespace std;
int main()
{
    int n,i,j,o,k;
    cin>>n;
    int s[n];
    for(i=0;i<n;i++)
    {
        cin>>s[i];
    }
    for(i=0;i<n;i++)
    {
        int j=0;
        for(j=i+1;j<n;j++)
        {   if(s[i]==s[j])
            {
                for(k=j;k<n;k++)
                {
                    s[k]=s[k+1];
                }
                n=n-1;
                j=j-1;
            }
        }
    }
    for(i=0;i<n;i++)
           cout<<s[i]<<" ";
}
