#include <iostream>
using namespace std;
int main()
{
    signed int c,d;
    int a,b;
    scanf("%d/%d %d/%d",&c,&a,&d,&b);
    if(1.0*c/a>1.0*d/b)
      cout<<d<<"/"<<b<<","<<c<<"/"<<a;
    else if(1.0*c/a==1.0*d/b)
            cout<<"Equal";
         else
            cout<<c<<"/"<<a<<","<<d<<"/"<<b;
}
