#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;
int main()
{
    double a,b,c,x1,x2,x,d;
    cin>>a>>b>>c;
    if(a==0&&b!=0)
    {
        x=-c/b;
        cout<<fixed<<setprecision(3)<<"x="<<x<<endl;
    }
    else if(a==0&&b==0)
           cout<<"No solution";
    else
    {
        d=(b*b)-(4*a*c);
        if(d==0)
        {
            x=(-b)/(2*a);
            cout<<fixed<<setprecision(3)<<"x="<<x<<endl;
        }
        else if(d>0)
        {
            x1=(-b-sqrt(d))/(2*a);
            x2=(-b+sqrt(d))/(2*a);
            if(x1<x2)
               cout<<fixed<<setprecision(3)<<"x1="<<x1<<endl<<"x2="<<x2<<endl;
            else
               cout<<fixed<<setprecision(3)<<"x1="<<x2<<endl<<"x2="<<x1<<endl;
        }
        else
            cout<<"No solution"<<endl;
    }
    return 0;
}
