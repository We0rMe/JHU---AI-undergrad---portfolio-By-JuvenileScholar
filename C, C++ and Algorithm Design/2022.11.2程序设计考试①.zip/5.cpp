#include <iostream>
using namespace std;
int main()
{
    char a;
    int x;
    scanf("%c",&a);
    x=a;
    if(x>=65&&x<=90)
      cout<<"Upper-case Letter";
    else if(x>=97&&x<=122)
            cout<<"Lower-case Letter";
         else if(x>=48&&x<=57)
                 cout<<"Digital";
              else if(x==43||x==45||x==42||x==47||x==61) 
                      cout<<"Operator";
                   else if(x==40||x==41||x==91||x==93||x==123||x==125)
                           cout<<"Bracket";
                        else 
                           cout<<"Not classified";
              
      
    
}

