#include <iostream>
#include <math.h>
using namespace std;
class Shape
{
public:
    static const double PI;
	virtual double Surrand()=0;		//����״���ܳ�
	virtual double Contain()=0;		//����״�����
	virtual void Show()=0;			//��ʾ����״�Ļ�������
};
const double Shape::PI=3.1415926535898;
//start
class Circle:public Shape
{
protected:
    double r;
public:
    Circle(double a):r(a)
    {}
    double Surrand()
    {
        return 2*PI*r;
    }
    double Contain()
    {
        return PI*r*r;
    }
    void Show()
    {
        cout<<fixed;
        cout.precision(3);
        cout<<"Circle:"<<endl;
        cout<<"Radius="<<r<<endl;
        cout<<"Perimeter="<<Surrand()<<","<<"Area="<<Contain()<<endl;
    }
};
class Rectangle:public Shape
{
protected:
    double len;
    double open;
public:
    Rectangle(double a,double b):open(a),len(b)
    {}
    double Surrand()
    {
        return 2*len+2*open;
    }
    double Contain()
    {
        return len*open;
    }
    void Show()
    {
        cout<<fixed;
        cout.precision(3);
        cout<<"Rectangle:"<<endl;
        cout<<"Length="<<open<<","<<len<<endl;
        cout<<"Perimeter="<<Surrand()<<","<<"Area="<<Contain()<<endl;
    }
};
class Triangle:public Shape
{
protected:
    double x,y,z;
public:
    Triangle(double a,double b,double c):x(a),y(b),z(c)
    {
        if(a+b>c&&a+c>b&&b+c>a)
           ;
        else
        {
            x=y=z=0;
        }
    }
    double Surrand()
    {
        return x+y+z;
    }
    double Contain()
    {
        double t=(x+y+z)/2;
        return sqrt(t*(t-x)*(t-y)*(t-z));
    }
    void Show()
    {
        cout<<fixed;
        cout.precision(3);
        cout<<"Triangle:"<<endl;
        cout<<"Length="<<x<<","<<y<<","<<z<<endl;
        cout<<"Perimeter="<<Surrand()<<","<<"Area="<<Contain()<<endl;
    }
};
//end
int main()
{
    double x,y,z;
	Shape *q;
	cin>>x>>y>>z;
	cout.precision(3);
	cout<<fixed;
	q=new Circle(x);		//x��ΪԲ�İ뾶
	q->Show();
	cout<<q->Surrand()<<","<<q->Contain()<<endl;
	delete q;
	q=new Rectangle(x,y);	//x��y��Ϊ�����εĿ�����
	q->Show();
	cout<<q->Surrand()<<","<<q->Contain()<<endl;
	delete q;
	q=new Triangle(x,y,z);	//x��y��z��Ϊ�����ε������߳�
	q->Show();
	cout<<q->Surrand()<<","<<q->Contain()<<endl;
	delete q;
	return 0;
}
