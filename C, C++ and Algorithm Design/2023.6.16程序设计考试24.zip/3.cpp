#include <iostream>
#include <stdlib.h> 
#include <string>
#include <set>
#include <list>
#include <map>
using namespace std;
class BS
{private:
    set<int> sx;
	int sd1,sd2;
public:
	BS(int a,int b):sd1(a),sd2(b)
	{	}
	void Insert(int x)
	{
		x=(x*sd1+sd2)%100;
		swap(sd1,sd2);
		sx.insert(x);
	}
	void Erase(int n)
	{
		if(sx.size()==0)
			throw(string("Set is empty."));
		if(sx.find(n)==sx.end())
			throw(*this);
		set<int>::iterator q;
		q=sx.find(n);
		sx.erase(q);
	}
	void Show()
	{
		set<int>::iterator q;
		q=sx.begin();
		cout<<*q<<"(";
		cout<<sx.size()<<")"<<endl;
	}
};
class DV:public BS
{protected:
	list<int> sy;
public:
	DV(int a,int b):BS(a,b)
	{	}
	void Insert(int x)
	{
		BS::Insert(x);
		sy.push_back(x);
	}
	void Erase(int n)
	{
		list<int>::iterator q;
		int k=0;
		if(sy.size()==0)
			throw(string("List is empty."));
		else
		{
			for(q=sy.begin();q!=sy.end();q++)
				if(*q==n)
				{
					k++;
					sy.erase(q);
				}
			if(k==0)
				throw(*this);
		}
	}
	void Show()
	{
		list<int>::iterator q1;
		list<int>::reverse_iterator q2;
		q1=sy.begin();
		cout<<*q1<<"-";
		q2=sy.rbegin();
		cout<<*q2<<endl;
	}
};
class SN:public DV
{protected:
	map<int,int> sz;
public:
	SN(int a=2041,int b=1973):DV(a,b)
	{	}
	void Insert(int x)
	{
		DV::Insert(x);
		sz[x]++;
	}
	void Erase(int n)
	{
		map<int,int>::iterator q;
		if(sz.size()==0)
			throw(string("Map is empty."));
		if(sz.find(n)!=sz.end())
			throw(*this);
		else
		{
			for(q=sz.begin();q!=sz.end();q++)
				if((*q).first==n)
				{
					sz.erase(q);
					break;
				}
		}
	}
	void Show()
	{
		map<int,int>::iterator q;
		q=sz.begin();
		cout<<q->first<<endl;
	}
};
SN gbt;
void Fun(int n)
{
	srand(n);
	int k;
	k=rand()%(n*8);
	switch(k%7)
	{
		case 0:
			gbt.Insert(k);break;
		case 1:
			gbt.Erase(k);break;
		case 2:
			gbt.DV::Insert(k);break;
		case 3:
			gbt.DV::Erase(k);break;
		case 4:
			gbt.BS::Insert(k);break;
		case 5:
			gbt.BS::Erase(k);break;
	}
}
int main()
{
	int x,n=0;
//start
    try
    {
        for(n=1; ;n++)
        {
            cin>>x;
            if(x>0)
              Fun(x);
            else
              break;
        }
    }
    catch (string a)
    {
        cout<<a<<endl;
    }
    catch (DV a)
    {
        a.DV::Show();
    }
    catch (SN a)
    {
        a.SN::Show();
    }
    catch (BS a)
    {
        a.BS::Show();
    }
    cout<<n<<" numbers accepted."<<endl;
//end
}
