#include <iostream>
#include <string>
using namespace std;
//start
class Pet
{
protected:
    string name;
    int size;
public:
    Pet(string a,int b):name(a),size(b)
    {}
    virtual string GetName()
    {
        return name;
    }
    virtual string GetSize()
    {
        if(size<25) return "mini";
        else if(size<40) return "small";
        else return "big";
    }
    virtual string ToString()=0;
    virtual void Cry(int n)=0;
};
//end
class Dog:public Pet
{
public:
	Dog(string a,int b):Pet(a,b)	{	}
	string ToString()
	{	return GetName()+"("+GetSize()+",dog)";		}
	string GetName()
	{	return name;	}
	string GetSize()
	{	if(size<25) return "mini";
		else if(size<40) return "small";
		else return "big";
	}
	void Cry(int n)
	{	cout<<"Won";
		for(int i=1;i<n;i++)
			cout<<",won";
		cout<<"...";
	}
};
class Cat:public Pet
{
public:
	Cat(string a,int b):Pet(a,b)	{	}
	string ToString()
	{	return GetName()+"("+GetSize()+",cat)";		}
	string GetName()
	{	return name;	}
	string GetSize()
	{	if(size<20) return "mini";
		else return "normal";
	}
	void Cry(int n)
	{	cout<<"Miao";
		for(int i=1;i<n;i++)
			cout<<",miao";
		cout<<"...";
	}
};
class Pig:public Pet
{
public:
	Pig(string a,int b):Pet(a,b)	{	}
	string ToString()
	{	return GetName()+"("+GetSize()+",pig)";		}
	string GetName()
	{	return name;	}
	string GetSize()
	{	if(size<30) return "small";
		else return "normal";
	}
	void Cry(int n)
	{	cout<<"Hen";
		for(int i=1;i<n;i++)
			cout<<",en,hen";
		cout<<"...";
	}
};
int main()
{
	Pet *ps[]={new Cat("Tom",30),new Dog("Yello",24),new Pig("Huahua",20),new Cat("Jerry",10),
		new Dog("Pipy",50),new Pig("ChoCho",33),new Cat("Nana",30),new Cat("Miemie",30),};
	int n,k;
	cin>>n>>k;
	cout<<ps[n]->ToString()<<" - "<<ps[n]->GetName()<<" , "<<ps[n]->GetSize()<<endl;
	ps[n]->Cry(k);
	for(int i=0;i<8;i++)
		delete ps[i];
}
