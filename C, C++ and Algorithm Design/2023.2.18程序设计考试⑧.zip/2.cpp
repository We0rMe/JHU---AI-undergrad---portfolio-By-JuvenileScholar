#include <iostream>
using namespace std;
int hcf(int a,int b)
{
    if(b!=0)
      return hcf(b,a%b);
    else
      return a;
}
int main()
{
   int a,b,c,d;
   cin>>a>>b;
   c=a;
   d=b;
   if(a==0&&b==0)
     cout<<"Input error.";
   else
   {   a=(a>0)?a:-a;
       b=(b>0)?b:-b;
       cout<<"GCD("<<c<<","<<d<<")="<<hcf(a,b);
   }
}
