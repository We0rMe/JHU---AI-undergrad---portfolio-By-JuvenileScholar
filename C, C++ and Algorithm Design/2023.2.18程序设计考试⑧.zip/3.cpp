#include <iostream>
using namespace std;
int oui(int m,int n)
{   int k;
    int a,b;
    a=m;
    b=n;
    if(m<=0||n<0)
       k=0;
    else if(n==0||m==n)
            k=1;
         else
         {
            k=oui(m-1,n-1)+oui(m-1,n); 
         }
    return k;
}
int main()
{
   int z,x;
   cin>>z>>x;
   int k;
   k=oui(z,x);
   if(k==0)
     cout<<"Input error.";
   else
     cout<<"C("<<z<<","<<x<<")="<<k;
}
