//start
#include <iostream>
using namespace std;
struct ZUO
{
    double posx;
    double posy;
};
struct ZUO GetCenter(struct ZUO *a,int n)
{
    double x=0,y=0;
    int i;
    for(i=0;i<n;i++)
    {
        x+=(*(a+i)).posx;
    }
    x=x/n;
    for(i=0;i<n;i++)
    {
        y+=(*(a+i)).posy;
    }
    y=y/n;
    return {x,y};
}
int main()
{   int n;
    cin>>n;
    struct ZUO points[n],p0;
    int i;
    for(i=0;i<n;i++)
    {
        cin>>points[i].posx>>points[i].posy;
    }
    
//end
//��start��end֮���д����,�������ֲ����޸ġ�
	p0=GetCenter(points,n);
	printf("(%.2f , %.2f)",p0.posx,p0.posy);
	return 0;
}
