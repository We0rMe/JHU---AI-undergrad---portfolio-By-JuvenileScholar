#include <iostream>
#include <iomanip>
#include <math.h>
#include <stdlib.h>
using namespace std;
//start
class MyPoint
{
  private:
    double x,y;
  public:
    MyPoint()
    {
        x=0;
        y=0;
    }
    MyPoint(double a,double b)
    {
        x=a;
        y=b;
    }
    MyPoint(double a)
    {
        x=a;
        y=0;
    }
    void Show()
    {
        cout<<fixed;
        cout.precision(1);
        cout<<'('<<x<<','<<y<<')';
    }
    double DistanceTo(MyPoint a)
    {
        double s;
        s=sqrt((x-a.x)*(x-a.x)+(y-a.y)*(y-a.y));
        return s;
    }
};
//end
int main()
{
 int i,k;
 double a,b,c;
 cin>>k;
 srand(k);
 a=rand()/375.9;
 b=rand()/1041.3;
 c=rand()/787.2;
 MyPoint p1(a,b),p2(c);
 p1.Show();
 cout<<endl<<p2.DistanceTo(p1)<<endl;
 p2.Show();
 cout<<endl;
}
