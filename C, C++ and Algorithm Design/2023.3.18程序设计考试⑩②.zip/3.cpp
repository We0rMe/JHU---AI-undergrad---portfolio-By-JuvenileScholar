#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;
//start
char w[100];
class MyDate
{
  private:
    int year,month,day;
  public:
    MyDate(int a)
    {
        year=a;
        month=1;
        day=1;
    }
    MyDate(int a,int b,int c)
    {
        year=a;
        month=b;
        day=c;
    }
    void Show()
    {
        cout<<year<<'/'<<month<<'/'<<day;
    }
    char* ToString()
    {
        w[0]=(char)(year/1000+48);
        w[1]=(char)(year%1000/100+48);
        w[2]=(char)(year%100/10+48);
        w[3]=(char)(year%10+48);
        w[4]='/';
        if(month<10)
        { 
            w[5]=(char)(month+48);
            w[6]='/';
            if(day<10)
            {   
                w[7]=(char)(day+48);
                w[8]='\0';
            }
            else
            {
                w[7]=(char)(day/10+48);
                w[8]=(char)(day%10+48);
                w[9]='\0';
            }
        }    
        else
        {
            w[5]=(char)(month/10+48);
            w[6]=(char)(month%10+48);
            w[7]='/';
            if(day<10)
            {
                w[8]=(char)(day+48);
                w[9]='\0';
            }
            else
            {
                w[8]=(char)(day/10+48);
                w[9]=(char)(day%10+48);
                w[10]='\0';
            }
        }
        return w;
    }
};
//end
int main()
{
 int a,b,c,k;
 cin>>k;
 srand(k);
 a=rand()%520+1500;
 b=rand()%12+1;
 c=rand()%30+1;
 MyDate d1(a,b,c),d2(a);
 d1.Show();
 cout<<endl;
 d2.Show();
 cout<<endl<<d1.ToString()<<endl;
}
