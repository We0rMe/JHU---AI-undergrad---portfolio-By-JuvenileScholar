#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;
//start
#include <string.h>
char q[50];
class MyTime
{
  private:
    int hour,min;
  public:
    MyTime()
    {
        hour=0;
        min=0;
    }
    MyTime(int a,int b)
    {
        hour=a;
        min=b;
    }
    void Show()
    {
        if(hour<12)
        {
            if(min<10)
            {
                cout<<hour<<':'<<0<<min<<"am";
            }
            else
                cout<<hour<<':'<<min<<"am";
        }
        else if(hour==12)
        {
            if(min<10)
            {
                cout<<12<<':'<<0<<min<<"pm";
            }
            else
                cout<<12<<':'<<min<<"pm";
        }
        else
        {
            if(min<10)
            {
                cout<<hour-12<<':'<<0<<min<<"pm";
            }
            else
               cout<<hour-12<<':'<<min<<"pm";
        }
    }
    char* ToString()
    {
       if(hour<10)
       {
           if(min<10)
           {
               q[0]=(char)(hour+48);
               q[1]=':';
               q[2]=(char)(min+48);
               q[3]='a';
               q[4]='m';
               q[5]='\0';
           }
           else if(min>=10)
                {
                    q[0]=(char)(hour+48);
                    q[1]=':';
                    q[2]=(char)(min/10+48);
                    q[3]=(char)(min%10+48);
                    q[4]='a';
                    q[5]='m';
                    q[6]='\0';
                }
                
       }
       else if(hour>=10&&hour<12)
            {
                if(min<10)
                {
                    q[0]=(char)(hour/10+48);
                    q[1]=(char)(hour%10+48);
                    q[2]=':';
                    q[3]=(char)(min+48);
                    q[4]='a';
                    q[5]='m';
                    q[6]='\0';
                }
                else if(min>=10)
                     {
                         q[0]=(char)(hour/10+48);
                         q[1]=(char)(hour%10+48);
                         q[2]=':';
                         q[3]=(char)(min/10+48);
                         q[4]=(char)(min%10+48);
                         q[5]='a';
                         q[6]='m';
                         q[7]='\0';
                     }
            }
            else if(hour==12)
                 {
                     if(min<10)
                     {
                         q[0]=(char)49;
                         q[1]=(char)50;
                         q[2]=':';
                         q[3]=(char)(min+48);
                         q[4]='p';
                         q[5]='m';
                         q[6]='\0';
                     }
                     else if(min>=10)
                          {
                              q[0]=(char)49;
                              q[1]=(char)50;
                              q[2]=':';
                              q[3]=(char)(min/10+48);
                              q[4]=(char)(min%10+48);
                              q[5]='p';
                              q[6]='m';
                              q[7]='\0';
                          }
                 }
                 else if(hour>12&&hour<22)
                      {
                          if(min<10)
                          {
                              q[0]=(char)((hour-12)+48);
                              q[1]=':';
                              q[2]=(char)(min+48);
                              q[3]='p';
                              q[4]='m';
                              q[5]='\0';
                          }
                          else if(min>=10)
                               {
                                   q[0]=(char)((hour-12)+48);
                                   q[1]=':';
                                   q[2]=(char)(min/10+48);
                                   q[3]=(char)(min%10+48);
                                   q[4]='p';
                                   q[5]='m';
                                   q[6]='\0';
                               }
                      }
                      else if(hour>=22)
                      {
                          if(min<10)
                          {
                              q[0]=(char)((hour-12)/10+48);
                              q[1]=(char)((hour-12)%10+48);
                              q[2]=':';
                              q[3]=(char)(min+48);
                              q[4]='p';
                              q[5]='m';
                              q[6]='\0';
                          }
                          else if(min>=10)
                               {
                                   q[0]=(char)((hour-12)/10+48);
                                   q[1]=(char)((hour-12)%10+48);
                                   q[2]=':';
                                   q[3]=(char)(min/10+48);
                                   q[4]=(char)(min%10+48);
                                   q[5]='p';
                                   q[6]='m';
                                   q[7]='\0';
                               }
                      }
        return q;
    }
};
//end
int main()
{
	int a,b,k;
	cin>>k;
	srand(k);
	a=rand()%24;
	b=rand()%60;
	MyTime t1(a,b);
	t1.Show();
	cout<<endl<<t1.ToString()<<endl;
    t1.Show();
}