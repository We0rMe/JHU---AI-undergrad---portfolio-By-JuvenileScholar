#include <iostream>
using namespace std;
//start
char q[50];
class SString
{  
  private:
    char w[50];
  public:
    SString()
    {
        w[0]='\0';
    }
    SString(char *a)
    {
       int i;
       for(i=0;*(a+i)!='\0';i++)
           w[i]=*(a+i);
       w[i]='\0';
    }
    void Show()
    {
        cout<<w;
    }
    int Length()
    {
        int k;
        for(k=0;w[k]!='\0';k++)
            ;
        return k;
    }
    char* Upper()
    {
        int i;
        for(i=0;w[i]!='\0';i++)
        {
            if(w[i]>=97&&w[i]<=122)
              q[i]=(char)(w[i]-32);
            else
              q[i]=w[i];
        }
        return q;
    }
    void ToLower()
    {   
        for(int i=0;w[i]!='\0';i++)
        {
           if(w[i]>=65&&w[i]<=90)
              w[i]=(char)(w[i]+32);
        }
    }
};
//end
int main()
{
 char x[51];
 cin.getline(x,50);
 SString s(x);
 s.Show();
 cout<<endl;
 cout<<s.Upper()<<endl;
 s.Show();
 cout<<endl;
 s.ToLower();
 s.Show();
 cout<<endl;
 cout<<"Length="<<s.Length()<<endl;
}
