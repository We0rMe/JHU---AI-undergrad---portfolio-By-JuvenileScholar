#include <iostream>
#include <stdlib.h>
#include <algorithm>
using namespace std;
//start
class MyClock
{
  private:
    int h,m,s;
    friend istream& operator>>(istream& is,MyClock& a);
    friend ostream& operator<<(ostream& os,MyClock& a);
  public:
    MyClock()
    {
        h=0,m=0,s=0;
    }
    MyClock(int a,int b=0,int c=0)
    {   
        if(c>0&&c<60&&b>0&&b<60&&a>0&&a<24)
        {
          h=a;
          m=b;
          s=c;
        }
        else
        {
            h=0;
            m=0;
            s=0;
        }
    }
    MyClock operator++()
    {
        s++;
        if(s>=60)
        {
            s=s-60;
            m=m+1;
        }
        if(m>=60)
        {
            m=m-60;
            h=h+1;
        }
        if(h>=24)
        {
            h=h-24;
        }
        return *this;
    }
    MyClock operator++(int)
    {
        MyClock w;
        w.h=h;
        w.m=m;
        w.s=s;
        ++s;
        if(s>=60)
        {
            s=s-60;
            m=m+1;
        }
        if(m>=60)
        {
            m=m-60;
            h=h+1;
        }
        if(h>=24)
        {
            h=h-24;
        }
        return w;
    }
    MyClock operator+(int a)
    {
        MyClock w;
        int u;
        w.h=h;
        w.m=m;
        w.s=s+a;
        if(w.s>=60)
        {   u=w.s;
            w.s=w.s-w.s/60*60;
            w.m=w.m+u/60;
        }
        if(w.m>=60)
        {   u=w.m;
            w.m=w.m-w.m/60*60;
            w.h=w.h+u/60;
        }
        if(w.h>=24)
        {
            w.h=w.h-w.h/24*24;
        }
        return w;
    }
};
istream& operator>>(istream& is,MyClock& a)
{
    int q,w=1,e=1;
    is>>q>>w>>e;
    if(q>=0&&q<=24&&w>=0&&w<60&&e>=0&&e<60)
    {
        MyClock o(q,w,e);
        a.h=o.h;
        a.m=o.m;
        a.s=o.s;
        return is;
    }
    else
    {
        return is;
    }
}
ostream& operator<<(ostream& os,MyClock& a)
{
    if(a.h<10)
      os<<0;
    os<<a.h<<":";
    if(a.m<10)
      os<<0;
    os<<a.m<<":";
    if(a.s<10)
      os<<0;
    os<<a.s;
    return os;
}
//end
int main()
{
	int n,i;
	cin>>n;
	MyClock ck1(n,n/2,n),ck2(2),ck3(3);
	ck2=(ck1++)+60;
	ck3=(++ck1)+3600;
	cout<<ck1<<endl;
	cout<<ck2<<endl;
	cout<<ck3<<endl;
}
