#include <iostream>
using namespace std;
//start
class SString
{
  private:
    char w[51];
    friend ostream& operator<<(ostream& os,SString& a);
  public:
    SString()
    {
        w[0]='\0';
    }
    SString(char* a)
    {
        int i;
        for(i=0;*(a+i)!='\0';i++)
        {
            w[i]=*(a+i);
        }
        w[i]='\0';
    }
    int Length()
    {
        int i=0;
        for(i=0;w[i]!='\0';i++)
           ;
        return i;
    }
    SString operator+(SString s)
    {
        SString x;
        int len1=Length();
        int len2=s.Length();
        int i;
        if(len1+len2>50)
          throw("Error catenate.");
        else
        {
            for(i=0;i<Length();i++)
               x.w[i]=w[i];
            for(i=Length();i<Length()+s.Length();i++)
               x.w[i]=s.w[i-Length()];
        }
        x.w[i]='\0';
        return x;
    }
    char& operator[](int a)
    {
        if(a<0||a>=Length())
          throw("Error range [].");
        return w[a];
    }
};
ostream& operator<<(ostream& os,SString& a)
{
    cout<<a.w;
    return os;
}

//end
int main()
{
	char x[51];
	cin>>x;
	SString s1(x);
	cout<<"S1="<<s1<<"("<<s1.Length()<<")"<<endl;
	cin>>x;
	SString s2(x),s3;
	cout<<"S2="<<s2<<"("<<s2.Length()<<")"<<endl;
	try
	{
		s3=s1+s2;
		cout<<"S1+S2="<<s3<<"("<<s3.Length()<<")"<<endl;
		for(int i=0;i<20;i++)
			cout<<s3[i]<<" ";
	}
	catch(const char* err)
	{
		cout<<err<<endl;
	}
}
