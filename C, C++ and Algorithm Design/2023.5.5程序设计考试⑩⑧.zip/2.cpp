#include <iostream>
#include <stdlib.h>
#include <algorithm>
using namespace std;
//start
class MyDate
{
  private:
    int y,m,d;
    friend ostream& operator<<(ostream& os,MyDate& a);
  public:
    MyDate(int a,int b=1,int c=1)
    {   if(b>12||b<=0||c>31||c<=0||(a%400==0&&b==2&&c>29)||(a%100!=0&&a%4==0&&b==2&&c>29)||(a%400!=0&&b==2&&c>28)||(b==4&&b==6&&b==9&&b==11&&c>30))
        {
           y=m=d=-1;
        }
        else
        {
          y=a;
          m=b;
          d=c;
        }
    }
    bool IsValid()
    {
        if(y==-1)
          return false;
        else
          return true;
    }
    MyDate operator++()
    {
        d=d+1;
        if(y%400==0&&m==2&&d==30)
        {
            d=1;
            m++;
        }
        else if(y%400!=0&&m==2&&d==29)
                  {
                     d=1;
                     m++;
                  }
                  else if(m==4||m==6||m==9||m==11)
                       {  
                           if(y%400!=0&&d==31)
                          {
                            d=1;
                            m++;
                          }
                       }
                       else if(m==1||m==3||m==5||m==7||m==8||m==10||m==12)
                            { 
                                if(y%400!=0&&d==32)
                              {
                                 d=1;
                                 m++;
                              }
                            }
        if(m==13)
        {
            m=1;
            y++;
        }
        return *this;
    }
    MyDate operator++(int)
    {
        MyDate w(0,0,0);
        w.y=y;
        w.m=m;
        w.d=d;
        d=d+1;
        if(y%400==0&&m==2&&d==30)
        {
            d=1;
            m++;
        }
        else if(y%400!=0&&m==2&&d==29)
                  {
                     d=1;
                     m++;
                  }
                  else if(m==4||m==6||m==9||m==11)
                       {  
                           if(y%400!=0&&d==31)
                          {  d=1;
                             m++;
                             
                          }
                       }
                       else if(m==1||m==3||m==5||m==7||m==8||m==10||m==12)
                            {  
                                if(y%400!=0&&d==32)
                               {
                                  d=1;
                                  m++;
                               }
                            }
        if(m==13)
        {
            m=1;
            y++;
        }
        return w;
    }
};
ostream& operator<<(ostream& os,MyDate& a)
{
    if(a.IsValid())
    {
        cout<<a.y<<"/";
        if(a.m<10)
          cout<<0;
        cout<<a.m<<"/";
        if(a.d<10)
          cout<<0;
        cout<<a.d;
        return os;
    }
    else
    {
        cout<<"[#Invalid]";
        return os;
    }
}
//end
int main()
{
	int y,m,d;
	cin>>y>>m>>d;
	MyDate w1(y,m,d),w2(w1),w3(w1);
	cout<<w1<<endl;
	w2=w1++;
	w3=++w1;
	cout<<w2<<endl;
	cout<<w3<<endl;
}
