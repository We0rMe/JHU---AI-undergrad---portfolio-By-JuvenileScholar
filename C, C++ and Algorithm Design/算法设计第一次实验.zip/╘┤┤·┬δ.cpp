#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <map>
#define N 1000000
using namespace std;
bool dis=false;  //���������һ������Ľ�� 
struct time{ 
	int y,m,d;
	string s;
} Time;
vector<struct time> ques;
typedef vector<struct time>::iterator it;
bool run(int& y) //���� 
{
	return (y%400==0)||(y%4==0&&y%100!=0);
}
bool judge(int year, int month, int day) //���ںϷ��ж� 
{  
    if (year < 1 || month < 1 || day < 1) {  
        return false;  
    }  
    if (month > 12) {  
        return false;  
    }  
    int maxDays = 31;  
    switch (month) {  
        case 4:maxDays = 30;  
               break;  
        case 6:maxDays = 30;  
               break;   
        case 9:maxDays = 30;  
               break;   
        case 11:maxDays = 30;  
                break;  
        case 2:  
            maxDays = run(year) ? 29 : 28;  
            break;  
    }  
    return day <= maxDays;  
} 
int compare(struct time& a,struct time& b) //���ڱȽ� 
{
	if(a.y>b.y) return 1;
	else if(a.y<b.y) return -1;
	else if(a.m>b.m) return 1;
	else if(a.m<b.m) return -1;
	else if(a.d>b.d) return 1;
	else if(a.d<b.d) return -1;
	else if(a.d==b.d) return 0;  
}
void QuickSort(it a,int begin,int end) //�������� 
{
	if(begin>=end) return;
	else
	{
		int i=begin,j=end;
		struct time midday=*(a+(begin+end)/2);
		
		while(i<j)
		{
			while(compare(*(a+i),midday)<0) i++;
			while(compare(*(a+j),midday)>0) j--;
		    if(i<=j)
		    {
		    	swap(*(a+i),*(a+j));
		    	i++;j--;
			}
		}
		if(!dis)
		{
			cout<<ques[begin].y<<'-'<<ques[begin].m<<'-'<<ques[begin].d<<' '<<ques[begin].s<<" | ";
	        cout<<ques[begin+1].y<<'-'<<ques[begin+1].m<<'-'<<ques[begin+1].d<<' '<<ques[begin+1].s<<" | ";
			cout<<ques[end-1].y<<'-'<<ques[end-1].m<<'-'<<ques[end-1].d<<' '<<ques[end-1].s<<" | ";
	        cout<<ques[end].y<<'-'<<ques[end].m<<'-'<<ques[end].d<<' '<<ques[end].s<<endl<<endl;
			dis=true;
		}
		if(begin<j) QuickSort(a,begin,j);
		if(end>i) QuickSort(a,i,end); 
	}
}
bool sameDay(struct time& a,struct time& b) //�������� 
{
	return (a.y==b.y&&a.m==b.m&&a.d==b.d);
}
int tog(struct time& a,int k) //�����ظ�����λ�� 
{
	for(int i=k-1;i>=0;i--)
	{
		if(sameDay(a,ques[i]))
		    return i;
	}
	return -1; //û�оͷ���-1 
}
int main()
{
	fstream f("d:\\data.txt",ios::in);
	int i,j,k=0,year,month,day;
	string message;
	char ch;
	for(i=0;i<N;i++)
	{
		f>>year>>ch>>month>>ch>>day>>message;
		if(!judge(year,month,day)) continue; //���Ϸ������� 
		Time.y=year;Time.m=month;Time.d=day;Time.s=message;
		int sit=tog(Time,k);
		if(sit==-1)  //û�ظ� 
		{
			ques.push_back(Time);
		    //cout<<ques[k].y<<'-'<<ques[k].m<<'-'<<ques[k].d<<' '<<ques[k].s<<endl;
		    k++;
		}  
		else    //���ظ�
		{
			int a[4]={0};  //����ֹ�����ĸ��A~D 
			for(int j=0;j<Time.s.length();j++)
			   a[int((Time.s)[j]-'A')]++;
			for(int j=0;j<ques[sit].s.length();j++)
			   a[int((ques[sit].s)[j])-'A']++;
			string aStr;
			for(int j=0;j<4;j++)
			{
			    if(a[j]!=0)
				   aStr+=(char)('A'+j);	
			}
			ques[sit].s=aStr;
			/*cout<<sit<<endl;    //�����Ƿ�ɹ�ȥ�ء��޸�
			cout<<ques[sit].y<<'-'<<ques[sit].m<<'-'<<ques[sit].d<<' '<<ques[sit].s<<endl;//���޸Ĺ��� 
			cout<<year<<'-'<<month<<'-'<<day<<' '<<message<<endl;    
			break;*/
		}
	}
	f.close();
	cout<<"Total = "<<k<<endl<<endl;
	QuickSort(ques.begin(),0,k-1);
	cout<<ques[0].y<<'-'<<ques[0].m<<'-'<<ques[0].d<<' '<<ques[0].s<<" | ";
	cout<<ques[1].y<<'-'<<ques[1].m<<'-'<<ques[1].d<<' '<<ques[1].s<<" | ";
	cout<<ques[2].y<<'-'<<ques[2].m<<'-'<<ques[2].d<<' '<<ques[2].s<<" | ";
	cout<<ques[k-3].y<<'-'<<ques[k-3].m<<'-'<<ques[k-3].d<<' '<<ques[k-3].s<<" | ";
	cout<<ques[k-2].y<<'-'<<ques[k-2].m<<'-'<<ques[k-2].d<<' '<<ques[k-2].s<<" | ";
	cout<<ques[k-1].y<<'-'<<ques[k-1].m<<'-'<<ques[k-1].d<<' '<<ques[k-1].s;
	return 0;
}

