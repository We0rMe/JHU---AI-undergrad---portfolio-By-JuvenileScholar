//start
#include <iostream>
using namespace std;
int main()
{
    int a[3];
    int i,j,k;
    for(i=0;i<3;i++)
       cin>>a[i];
    int *p;
    if(a[0]>a[1]&&a[0]<a[2]||a[0]<a[1]&&a[0]>a[2])
      p=&a[0];
    else if(a[1]>a[0]&&a[1]<a[2]||a[1]<a[0]&&a[1]>a[2])
            p=&a[1];
         else if(a[2]>a[0]&&a[2]<a[1]||a[2]<a[0]&&a[2]>a[1])
                p=&a[2];
//end
//��start��end֮���д����,�������ֲ����޸ġ�
    printf("%d",*p);
    return 0;
}
