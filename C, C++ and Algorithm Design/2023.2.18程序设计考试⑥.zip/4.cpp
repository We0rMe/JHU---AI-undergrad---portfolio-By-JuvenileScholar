#include <iostream>
using namespace std;
//start
void sort_int(int *a,int b)
{
    int i,j,min,k;
    for(i=1;i<b;i++)
    {   
        for(j=0;j<b-i;j++)
        {
           if(*(a+j)>*(a+j+1))
             swap(*(a+j),*(a+j+1));
        }
    }
}
//end
//��start��end֮���д����,�������ֲ����޸ġ�
int main()
{
	int i,n,x[1000];
	cin>>n;
	for(i=0;i<n;i++)
		cin>>x[i];
	sort_int(x,n);
	for(i=0;i<n;i++)
		cout<<x[i]<<' ';
    return 0;
}
