//start
#include <iostream>
using namespace std;
int main()
{
    int i,j,k=0,a[100]={0};
    for(i=0;i<100;i++)
    {        
        cin>>a[i];
        if(a[i]<0)
          break;
    }
    k=i;
    int b[k];
    for(i=0;i<k;i++)
       b[i]=a[i];
    int *p;
    int *q;
    int u=0;
    int w=0;
    for(i=0;i<k;i++)
    {
        if(b[i]<b[w])
            w=i;
    }
    p=&b[w];
    for(i=0;i<k;i++)
    {
       if(b[i]>=b[w])
             w=i;
        
    }
    q=&b[w];
//end
//��start��end֮���д����,�������ֲ����޸ġ�
    printf("%d",q-p);
    return 0;
}
