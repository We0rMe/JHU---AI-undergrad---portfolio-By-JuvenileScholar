//start
#include <iostream>
#include <math.h>
using namespace std;
void Rational(double x,int n)
{  
  int a,b;
  double i,j,k,w;
  w=x;
  if(x<1&&x>0&&n>0)
  {
      for(i=1;i<n;i++)
      {
          for(j=1;j<i;j++)
          {
              k=fabs(j/i-x);
              if(k<w)
               w=k,a=j,b=i;
          }
      }
      cout<<a<<"/"<<b;
  }
  else
    cout<<"Input Error.";
}
//end
//��start��end֮���д����,�������ֲ����޸ġ�
int main()
{
	double x;
	int n;
	cin>>x>>n;
	Rational(x,n);
    return 0;
}
