#include <iostream>
#include <stdlib.h>
using namespace std;
//start
int A=0;
int B=0;
int C=0;
class Test
{
  private:
    int a;
  public:
    Test(int o=0)
    {
        a=o;
        A++;
    }
    Test(Test const & w)
    {
        a=w.a;
        B++;
        A--;
    }
    void Show()
    {
        cout<<a<<' ';
    }
    Test operator=(Test w)
    {   
        a=w.a;
        C++;
        return a;
    }
    void Sum()
    {
        cout<<"Total:"<<B+C<<endl;
        cout<<"Type A:"<<A<<endl;
        cout<<"Type B:"<<B<<endl;
        cout<<"Type C:"<<C<<endl;
    }
};
//end
int main()
{
	int i,n;
	cin>>n;
	srand(n);
	Test x(1),y(2),z(3);
	for(i=0;i<n;i++)
	{
		switch(rand()%3)
		{
			case 0:
				{	Test x(rand()%10);
					x.Show();
				}
			case 1:
				{
					z=(rand()%1?x:y);
					z.Show();
					break;
				}
			case 2:
				{	Test *q=new Test(rand()%10);
					x=*q;
					x.Show();
					delete q;
					break;
				}
		}
	}
	cout<<endl;
	x.Sum();
}
