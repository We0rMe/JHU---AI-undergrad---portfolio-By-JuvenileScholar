#include <iostream>
using namespace std;
class String
{
private:
    char *buffer;
public:
    ~String()    	//��������
	{
        if(buffer!=NULL)
    		delete buffer;
	}
    void Show()
	{
        if(buffer!=NULL)
    		cout<<buffer;
	}
	int Length() const	//�󴮳�
	{
        if(buffer==NULL)
            return 0;
		int k=0;
		while(buffer[k]!='\0')
			k++;
		return k;
	}
//start
String()
{   
    buffer=new char[101];
    *buffer='\0';
}
String(char *a)
{   
    buffer=new char[101];
    int i;
    for(i=0;*(a+i)!='\0';i++)
       *(buffer+i)=*(a+i);
    *(buffer+i)='\0';
}
String(String const & a)
{  
    buffer=new char[101];
    int i;
    for(i=0;*(a.buffer+i)!='\0';i++)
      *(buffer+i)=*(a.buffer+i);
    *(buffer+i)='\0';
}
String operator=(String a)
{   
    int i;
    if(buffer!=a.buffer)
    {
      buffer=new char[101];
      for(i=0;*(a.buffer+i)!='\0';i++)
         *(buffer+i)=*(a.buffer+i);
      *(buffer+i)='\0';
      return *this;
    }
    else
      return *this;
}
String operator+(String a)
{
    String w(a);
    int i;
    for(i=0;*(buffer+i)!='\0';i++)
       *(w.buffer+i)=*(buffer+i);
    for(i=0;*(a.buffer+i)!='\0';i++)
       *(w.buffer+i+Length())=*(a.buffer+i);
    *(w.buffer+Length()+a.Length())='\0';
    return w;
}
bool operator==(String a)
{
    int i,k=1;
    if(Length()!=a.Length())
       return false;
    else
    {
        for(i=0;*(buffer+i)!='\0';i++)
        {
            if(*(buffer+i)!=*(a.buffer+i))
               k=0;  
        }
        if(k==0)
          return false;
        else
          return true;
    }
}
bool operator<(String a)
{
    int i=0,j=0;
    for(int k=0;k<Length();k++)
       i+=int(*(buffer+k));
    for(int p=0;p<a.Length();p++)
       j+=int(*(a.buffer+p));
    if(i<j)
       return true;
    else
       return false;
}
//end
};
int main()
{
	char buf[100];
	cin>>buf;
	String s1(buf);
	cin>>buf;
	String s2(buf),s3;
	if(s1==s2)
		s3=s1;
	else
	{
		if(s1<s2)
			s3=s1+s2;
		else
			s3=s2+s1;
	}
	s1.Show();
	cout<<endl;
	s2.Show();
	cout<<endl;
	s3.Show();
	cout<<endl;
	return 0;
}
