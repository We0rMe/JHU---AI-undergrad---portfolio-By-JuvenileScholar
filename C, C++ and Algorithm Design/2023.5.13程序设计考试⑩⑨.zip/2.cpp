#include <iostream>
#include <stdlib.h>
using namespace std;
//start
class Ints
{
  private:
    int* x;
    int y;
  public:
    Ints(int* a,int n)
    {   
        x=new int[n];
        int i;
        for(i=0;i<n;i++)
        {
            *(x+i)=*(a+i);
        }
        y=n;
    }
    void DelOdd()
    {   
        int o[y];
        int i,q;
        for(i=0,q=0;i<y;i++)
        {
            if(*(x+i)%2==0)
            {  
                o[q]=*(x+i);
                q++;
            }
        }
        y=q;
        for(i=0;i<y;i++)
           *(x+i)=o[i];
    }
    void Show()
    {
        int i;
        for(i=0;i<y;i++)
           cout<<*(x+i)<<' ';
         cout<<endl;
    }
};
//end
int main()
{
	int i,n;
	cin>>n;
	int *x=new int[n];
	int *y=new int[n];
	srand(n);
	for(i=0;i<n;i++)
		y[n-i-1]=x[i]=rand()%100;
	Ints A(x,n);
	Ints B(y,n-1);
	cout<<"1:Original\n";
	A.Show();
	B.Show();
	cout<<"2:A=B\n";
	A=B;
	A.Show();
	B.Show();
	cout<<"3:B.DelOdd\n";
	B.DelOdd();
	A.Show();
	B.Show();
}

