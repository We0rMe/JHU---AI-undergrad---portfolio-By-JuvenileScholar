#include <iostream>
#include <math.h>
using namespace std;
int zuida(int a,int b)
{
    int p=0;
    if(a<b)
      swap(a,b);
    while(p=a%b)
    {
        a=b;
        b=p;
    }
    return b;
}
int judge(int o)
{
    int y,w=1;
    y=(int)sqrt(o);
    if(y*y==o)
      return y;
    else
      return w;
}

int main()
{   int a,b,o;
    int c,n,i,j,k;
    cin>>n;
    for(c=n;c>=5;c--)
    {   o=0;
        for(a=1;a<c;a++)
        {
            if(judge(c*c-a*a)!=1)
            {
                b=sqrt(c*c-a*a);
                if(zuida(a,c)==1&&zuida(a,b)==1&zuida(b,c)==1&&b>a&&c>b)
                {
                    o=1;
                    break;
                }
            }
        }
        if(o==1)
          break;
    }
    cout<<a<<","<<b<<","<<c;
}
