#include <iostream>
#include <math.h>
#include <iomanip>
const double eps=1e-5;
double fangc(double a)
{
    double k;
    k=(2*sin(a))/(a+1)-cos(2*a)*exp(-a);
    return k;
}
using namespace std;
int main()
{
    double a,b,k,N;
    cin>>a>>b;
    if(a>b)
      swap(a,b);
    if(fangc(a)*fangc(b)<0)
    {
        while(fabs(b-a)>eps)
        {
            k=(a+b)/2.0;
            N=fangc(k);
            if(fabs(N)<eps)
              break;
            else if(fangc(k)*fangc(a)<0)
                 {
                     b=k;
                 }
                 else if(fangc(k)*fangc(b)<0)
                      {
                          a=k;
                      }
        }
        k=(a+b)/2;
        cout<<fixed<<setprecision(3)<<k;
    }
    else
        cout<<"Not found.";
}
