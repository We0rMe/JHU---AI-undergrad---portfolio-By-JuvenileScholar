#include <iostream>
using namespace std;
int main()
{
    int a,i,k=0;
    cin>>a;
    for(i=1;i<a;i++)
    {
        if(a%i==0)
          k+=i;
    }
    if(k==a)
      cout<<"Yes";
    else
      cout<<"No";
}
