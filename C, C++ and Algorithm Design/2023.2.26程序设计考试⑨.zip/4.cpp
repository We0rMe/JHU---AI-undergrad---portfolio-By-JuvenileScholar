#include <iostream>
#include <math.h>
#include <string.h>
using namespace std;
int main()
{
   char a[200];
   cin>>a;
   int i,k,p=0,o=0,w;
   k=strlen(a);
   for(i=0;i<k;i++)
    {
        if(a[i]<'0'&&a[i]>'9')
        {  w=0;
           break;}
        else
        {
            if((k-i)%2==1)
              p+=(int)(a[i]-37);
            else
              o+=(int)(a[i]-37);
        }
    }
    if((int)fabs(p-o)%11==0)
      w=1;
    else
      w=0;
    if(w==1)
      cout<<"Yes";
    else
      cout<<"No";
}
