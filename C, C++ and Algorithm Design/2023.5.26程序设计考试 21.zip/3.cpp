#include <iostream>
#include <algorithm>
using namespace std;
class MyDate
{protected:
    int year,month,day;
    static int mday[12];
public:
    MyDate(int a=-1,int b=-1,int c=-1):year(a),month(b),day(c)
    {
    	if(!IsValid())
			year=month=day=-1;
	}
	bool IsValid()
	{
		if(year<1 || year>9999 || month<1 || month>12)
			return false;
		int k=mday[month-1];
		if(month==2 && IsLeap())
			k=29;
		return day>0 && day<=k;
	}
	bool IsLeap()
	{
		return year%400==0 || year%4==0 && year%100!=0 ;
	}
	bool operator==(MyDate d2)
	{
		int t1=year*10000+month*100+day;
		int t2=d2.year*10000+d2.month*100+d2.day;
		if(!IsValid())
			t1=-1;
		return t1==t2;
	}
	bool operator<(MyDate d2)
	{
		int t1=year*10000+month*100+day;
		int t2=d2.year*10000+d2.month*100+d2.day;
		return t1<t2; 
	}
	MyDate& operator++()		//++ǰ�� 
	{
		if(!IsValid())
			return *this;
		day++;
		if(!IsValid())
		{
			day=1;
			month++;
			if(month>12)
			{
				month=1;
				year++;
			}
		}
		return *this;
	}
	MyDate operator++(int)	//����++ 
	{
		if(!IsValid())
			return *this;
		MyDate t(*this);
		++(*this);
		return t;
	}
	MyDate operator+(int n) 
	{
		if(!IsValid())
			return *this;
		MyDate t(*this);
		for(int i=0;i<n;i++)
			t++;
		return t;
	}
	friend ostream& operator<<(ostream& os,MyDate d);
};
int MyDate::mday[12]={31,28,31,30,31,30,31,31,30,31,30,31};
ostream& operator<<(ostream& os,MyDate d)
{
	if(!d.IsValid())
	{
		os<<"[#Invalid]";
		return os;
	}
	os<<d.year<<"/";
	if(d.month<10)
		os<<"0";
	os<<d.month<<"/";
	if(d.day<10)
		os<<"0";
	os<<d.day;
	return os;
}
//start
MyDate* Create(int n,int* x)
{
  MyDate* w=new MyDate[n];
  int i,j;
  for(i=0,j=0;i<n;i++,j=j+3)
  {
      *(w+i)=MyDate(*(x+j),*(x+j+1),*(x+j+2));
  }
  return w; 
}
void Select(MyDate* x,int n,MyDate &dmin,MyDate &dmax)
{
    dmin=MyDate(9999,12,31);
    dmax=MyDate(1980,1,1);
    for(int i=0;i<n;i++)
    {
        if(x[i].IsValid())
        {
            if(x[i]<dmin) 
               dmin=x[i];
            if(dmax<x[i]) 
               dmax=x[i];
        }
    }
}
int Count(MyDate d1,MyDate d2)
{
    int i,k=0;
    if(d1<d2)
    {
        while(d1<d2)
        {
            d1++;
            k++;
        }
        return k;
    }
    else if(d2<d1)
         {
            while(d2<d1)
            {
                d2++;
                k++;
            }
            return -k;
         }
         else
            return 0;
}
//end
int main()
{
	int i,n,x[3000];
	cin>>n;
	MyDate *d,d1,d2;
	srand(n);
	for(i=0;i<n*3;i++)
	{
		x[i++]=1980+rand()%50;
		x[i++]=rand()%12+1;
		x[i]=rand()%31+1;
	}
	d=Create(n,x);      //������n�����ڹ��ɵĶ�������
	Select(d,n,d1,d2);     //��ѡ���ڵ����ֵ����Сֵ 
	delete[] d;
	cout<<d1<<endl;
	cout<<d2<<endl;
	cout<<Count(d1,d2)<<endl;
	cout<<Count(d2,d1)<<endl;
}
