#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
class MyDate
{protected:
    int year,month,day;
    static int mday[12];
public:
    MyDate(int a=-1,int b=-1,int c=-1):year(a),month(b),day(c)
    {
    	if(!IsValid())
			year=month=day=-1;
	}
	bool IsValid()
	{
		if(year<1 || year>9999 || month<1 || month>12)
			return false;
		int k=mday[month-1];
		if(month==2 && IsLeap())
			k=29;
		return day>0 && day<=k;
	}
	bool IsLeap()
	{
		return year%400==0 || year%4==0 && year%100!=0 ;
	}
	bool operator==(MyDate d2)
	{
		int t1=year*10000+month*100+day;
		int t2=d2.year*10000+d2.month*100+d2.day;
		if(!IsValid())
			t1=-1;
		return t1==t2;
	}
	bool operator<(MyDate d2)
	{
		int t1=year*10000+month*100+day;
		int t2=d2.year*10000+d2.month*100+d2.day;
		return t1<t2; 
	}
	MyDate& operator++()		//++ǰ�� 
	{
		if(!IsValid())
			return *this;
		day++;
		if(!IsValid())
		{
			day=1;
			month++;
			if(month>12)
			{
				month=1;
				year++;
			}
		}
		return *this;
	}
	MyDate operator++(int)	//����++ 
	{
		if(!IsValid())
			return *this;
		MyDate t(*this);
		++(*this);
		return t;
	}
	MyDate operator+(int n) 
	{
		if(!IsValid())
			return *this;
		MyDate t(*this);
		for(int i=0;i<n;i++)
			t++;
		return t;
	}
	friend ostream& operator<<(ostream& os,MyDate d);
};
int MyDate::mday[12]={31,28,31,30,31,30,31,31,30,31,30,31};
ostream& operator<<(ostream& os,MyDate d)
{
	if(!d.IsValid())
	{
		os<<"[#Invalid]";
		return os;
	}
	os<<d.year<<"/";
	if(d.month<10)
		os<<"0";
	os<<d.month<<"/";
	if(d.day<10)
		os<<"0";
	os<<d.day;
	return os;
}
//start
class Book
{
private:
   string bname;
   string aname;
   MyDate publish;
   friend ostream& operator<<(ostream& os,Book& a);
public:
   Book(string a,string b,int x,int y,int z=1):bname(a),aname(b),publish(MyDate(x,y,z))
   {  }
   Book()
   {
       bname='\0';
       aname='\0';
       MyDate w;
       publish=w;
   }
   bool operator>(Book a)
   {
       if(publish<a.publish)
         return false;
       else
         return true;
   }
   bool operator==(Book a)
   {
       if(bname==a.bname&&aname==a.aname&&publish==a.publish)
         return true;
       else
         return false;
   }
   bool operator!=(Book a)
   {
       if(bname==a.bname&&aname==a.aname&&publish==a.publish)
         return false;
       else
         return true;
   }
 /*  void operator[](int i)
   {
       return 
   }*/
};
ostream& operator<<(ostream& os,Book& a)
{
    os<<a.bname<<"("<<a.aname<<"),["<<a.publish<<"]"<<"����";
    return os;
}
//end
int main()
{
	int a,b,c,i, j,n = 5;
	Book buf[5] = { Book("���ݽṹ", "���", 2000, 1), Book("���ݿ�", "����", 2012, 11,1), Book("�������", "����", 2020, 7,9) ,Book("���㷽��","�����",2018,8)};
	string s1, s2;
	cin >> s1 >> s2 >> a >> b >> c;
	buf[4] = Book(s1, s2, a, b, c);
	for (i = 1; i < n; i++)
		for (j = 0; j<n - i; j++)
			if (buf[j]>buf[j + 1])
				swap(buf[j], buf[j + 1]);
	for (i = j=1; i < n; i++)
		if (buf[i] != buf[j-1])
			buf[j++] = buf[i];
	n = j;
	for (int i = 0; i < n; i++)
		cout<<buf[i]<<endl;
}
