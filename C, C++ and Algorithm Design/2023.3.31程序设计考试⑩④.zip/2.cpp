#include <iostream>
#include <stdlib.h>
using namespace std;
//start
class Digit4
{
  private:
    int a,b,c,d;
  public:
    Digit4(int x=1111)
    {
        a=x/1000;
        b=x%1000/100;
        c=x%100/10;
        d=x%10;
        if(a==b||a==c||a==d||b==c||b==d||c==d)
          a=b=c=d=0;
    }
    void Set(int x)
    {
        int u,i,o,p;
        u=x/1000;
        i=x%1000/100;
        o=x%100/10;
        p=x%10;
        if(u==i||u==o||u==p||i==o||i==p||o==p)
        {
            a=0;b=0;c=0;d=0;
        }
        else
        {
            a=u;b=i;c=o;d=p;
        }
    }
    int IsValid()
    { 
       if(a==0&&b==0&&c==0&&d==0)
          return 0;
        else
          return 1;
    }
    void Test(int x,int &y,int &z)
    {
        int u,i,o,p;
        u=x/1000;
        i=x%1000/100;
        o=x%100/10;
        p=x%10;
        y=0;z=0; 
        if(u==a)
            y++;
        if(i==b)
            y++;
        if(o==c)
            y++;
        if(p==d)
            y++;
        if(a==i||a==o||a==p)
           z++;
        if(b==u||b==o||b==p)
           z++;
        if(c==u||c==i||c==p)
           z++;
        if(d==u||d==i||d==o)
           z++;
    }
    void Test(char* x,int &y,int &z)
    {
        int u,i,o,p;
        u=(int)*x-48;
        i=(int)*(x+1)-48;
        o=(int)*(x+2)-48;
        p=(int)*(x+3)-48;
        y=0;z=0;
        if(u==a)
          y++;
        if(i==b)
          y++;
        if(o==c)
          y++;
        if(p==d)
          y++;
        if(a==i||a==o||a==p)
          z++;
        if(b==u||b==o||b==p)
          z++;
        if(c==u||c==i||c==p)
          z++;
        if(d==u||d==i||d==o)
          z++;
    }
};
//end
int main()
{
	int k,n,a,b;
	char buf[10];
	cin>>k>>n>>buf;
	srand(k);
	Digit4 d;
	while(1)
	{
		a=rand()%10000;
		d.Set(a);
		if(d.IsValid())
		{
			cout<<a<<endl;
			break;
		}
	}
	d.Test(n,a,b);
	for(int i=1000;i>0;i/=10)
		if(n<i)
			cout<<"0";
		else
			break;
	cout<<n<<":"<<a<<"A"<<b<<"B\n";
	d.Test(buf,a,b);
	cout<<buf<<":"<<a<<"A"<<b<<"B\n";
}
