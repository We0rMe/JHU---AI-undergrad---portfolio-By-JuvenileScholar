#include <iostream>
#include <stdlib.h>
using namespace std;
//start
class Clock
{
  private:
    int h,m,s;
  public:
    Clock(int a)
    {
        h=a/3600;
        m=(a%3600)/60;
        s=(a%3600)%60;
    }
    Clock(int a,int b)
    {
        h=a;
        m=b;
        s=0;
    }
    Clock(int a,int b,int c)
    {
        h=a;m=b;s=c;
    }
    void Step()
    {
        s+=1;
        if(s>=60)
        {
            s=s-60;
            m=m+1;
        }
        if(m>=60)
        {
            m=m-60;
            h=h+1;
        }
        if(h>=24)
           h=h-24;
    }
    void Show()
    {
        if(h<10)
          cout<<"0";
        cout<<h<<":";
        if(m<10)
          cout<<"0";
        cout<<m<<":";
        if(s<10)
          cout<<"0";
        cout<<s;
        
    }
    void Set(int a)
    {
         h=a/3600;
    }
    void Set(int a,int b)
    {
        h=a;m=b;s=0;
    }
    void Set(int a,int b,int c)
    {
        h=a;m=b;s=c;
    }
};
//end
int main()
{
	int k,n;
	cin>>k>>n;
	Clock ck(n);
	n=k;
	ck.Show();
	cout<<endl;
	while(k>0)
	{
		ck.Step();
		k--;
		if(k==0||n%k==0)
		{
			cout<<n-k<<" seconds later:\n";
			ck.Show();
			cout<<endl;
			break;
		}
	}
}
