#include <iostream>
#include <stdlib.h>
using namespace std;
int X,Y;    	//���صĳߴ�
//start
#include <time.h>
class Robot
{
  private:
    int x,y,z;
  public:
    Robot(int a=3,int b=4,int c=1)
    {
        x=a;
        y=b;
        z=c;
    }
    void Rotate(int p)
    {
        if(p==1)
          z=z-1;
        if(p==2)
          z=z+1;
        if(z==5)
          z=1;
        if(z==0)
          z=4;
    }
    int Move(int n)
    {
        if(z==1)
        {
            int m=y;
            y=y-n;
            if(y<1)
            {
                y=1;
                return m-y;
            }
            else
            return n;
        }
        if(z==3)
        {
            int m=y;
            y=y+n;
            if(y>Y)
            {
                y=Y;
                return y-m;
            }
            else
            return n;
        }
        if(z==2)
        {
            int m=x;
            x=x+n;
            if(x>X)
            {
                x=X;
                return x-m;
            }
            else
            return n;
        }
        if(z==4)
        {
            int m=x;
            x=x-n;
            if(x<1)
            {
                x=1;
                return m-x;
            }
            return n;
        }
    }
    void Show()
    {
        cout<<"("<<x<<","<<y<<"):"<<z<<endl;
    }
};
//end
int main()
{
	int i,k,a,b,c,s=0;
	cin>>X>>Y>>k;
	srand(k);
	a=rand()%X+1; 
	b=rand()%Y+1;
	c=rand()%4+1;
	Robot r(a,b,c);
	cout<<X<<","<<Y<<endl;	//���صĳߴ�
	r.Show();	//��ʼλ�ü����� 
	k=k%15+5;
	for(i=0;i<k;i++)
	{
		if(rand()&1)
		{
			c=rand()%5;
			cout<<" S:"<<c+1;
			s+=r.Move(c+1);
		}
		else
		{
			c=rand()%2+1;
			cout<<" R:"<<c;
			r.Rotate(c);
		}
	}
	cout<<endl<<s<<" steps."<<endl;
	r.Show();
}
