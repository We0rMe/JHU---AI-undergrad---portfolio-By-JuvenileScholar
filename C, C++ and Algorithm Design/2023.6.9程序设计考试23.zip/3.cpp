#include <iostream>
using namespace std;
//start
class CFT
{
protected:
    int data;
public:
    CFT(int a=0):data(a)
    {}
    virtual void show()
    {
        cout<<"show="<<data<<endl;
    }
    void disp()
    {
        cout<<"disp="<<data<<endl;
    }
};
class CSN:public CFT
{
protected:
    int data;
public:
    CSN(int a,int b):data(a),CFT(b)
    {}
    virtual void show()
    {
        cout<<"show=("<<CFT::data<<","<<data<<")"<<endl;
    }
    void disp()
    {
        cout<<"disp=("<<CFT::data<<","<<data<<")"<<endl;
    }
    friend void fun();
};
//end
void fun()
{
	int a,b,c,d;
	cin>>a>>b>>c>>d;
	CFT ff(a),*ft=new CFT(c);
	CSN fs(a,b),*fn=new CSN(c,d);
	cout<<fs.data<<","<<fs.CFT::data<<","<<fn->data<<","<<fn->CFT::data<<endl;
	ff=fs;
	cout<<"*** ff<-fs ***\n";
	ff.show();
	ff.disp();
	ft=fn;
	cout<<"### ft<-fn ###\n";
	ft->show();
	ft->disp();
	ft->CFT::show();
	ft->CFT::disp();
}
int main()
{
	fun();
}
