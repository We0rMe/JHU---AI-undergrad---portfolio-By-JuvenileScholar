#include <iostream>
#include <string>
#include <set>
using namespace std;
class CMyPos
{
private:
    int m_posx,m_posy;
public:
    CMyPos(int x=0,int y=0):m_posx(x),m_posy(y)
    {
    }
	void Show()
	{
		printf("(%d,%d)",m_posx,m_posy);
	}
	double Distance2(CMyPos &P)
	{
		double dx,dy;
		dx=m_posx-P.m_posx;
		dy=m_posy-P.m_posy;
		return dx*dx+dy*dy;
	}
	CMyPos operator=(CMyPos &P)
	{
		m_posx=P.m_posx;
		m_posy=P.m_posy;
		return *this;
	}
	bool operator==(CMyPos &P)
	{
		return m_posx==P.m_posx && m_posy==P.m_posy;
	}
	friend bool operator<(const CMyPos &,const CMyPos &);
};
bool operator<(const CMyPos &P1,const CMyPos &P2)
{
	int a,b;
	a=P1.m_posx*P1.m_posx+P1.m_posy*P1.m_posy;
	b=P2.m_posx*P2.m_posx+P2.m_posy*P2.m_posy;
	return a<b;
}
//start
class PosSet:public set<CMyPos>
{
public:
    PosSet()
    {}
    PosSet operator+(CMyPos a)
    {
        insert(a);
        return *this;
    }
    PosSet operator+(PosSet a)
    {
        PosSet w=*this;
        PosSet::iterator i;
        for(i=a.begin();i!=a.end();i++)
        {
            w.insert(*i);
        }
        return w;
    }
    bool Find(const CMyPos x)
    {
        return count(x)>0;
    }
};
//end
int main()
{
	int i,k,n,x,y;
	PosSet sx,sy,sz;
	cin>>k>>n;
    cout<<k<<","<<n<<endl;
	for(i=0;i<n;i++)
	{
		k=k*28173+16849;
		x=k%10;
		k=k*28173+16849;
		y=k%10;
		sx=sx+CMyPos(x,y);
        sy=sy+CMyPos(y+1,x+1);
	}
	cout<<sx.size()<<","<<sy.size()<<endl;
    sz=sx+sy;
	k=k*28173+16849;
	x=k%10;
	k=k*28173+16849;
	y=k%10;
    cout<<"Look for ("<<x<<","<<y<<")\n";
    cout<<"X : "<<(sx.Find(CMyPos(x,y))?"YES":"NO")<<endl;
    cout<<"Y : "<<(sy.Find(CMyPos(x,y))?"YES":"NO")<<endl;
    cout<<"X+Y : "<<(sz.Find(CMyPos(x,y))?"YES":"NO")<<endl;
}
