#include <iostream>
#include <string>
using namespace std;
class MyDate
{protected:
    int year,month,day;
    static int mday[12];
public:
    MyDate(int a=-1,int b=-1,int c=-1):year(a),month(b),day(c)
    {
    	if(!IsValid())
			year=month=day=-1;
	}
	bool IsValid()
	{
		if(year<1 || year>9999 || month<1 || month>12)
			return false;
		int k=mday[month-1];
		if(month==2 && IsLeap())
			k=29;
		return day>0 && day<=k;
	}
	bool IsLeap()
	{
		return year%400==0 || year%4==0 && year%100!=0 ;
	}
	bool operator==(MyDate d2)
	{
		int t1=year*10000+month*100+day;
		int t2=d2.year*10000+d2.month*100+d2.day;
		if(!IsValid())
			t1=-1;
		return t1==t2;
	}
	bool operator<(MyDate d2)
	{
		int t1=year*10000+month*100+day;
		int t2=d2.year*10000+d2.month*100+d2.day;
		return t1<t2; 
	}
	MyDate& operator++()		//++ǰ�� 
	{
		if(!IsValid())
			return *this;
		day++;
		if(!IsValid())
		{
			day=1;
			month++;
			if(month>12)
			{
				month=1;
				year++;
			}
		}
		return *this;
	}
	MyDate operator++(int)	//����++ 
	{
		if(!IsValid())
			return *this;
		MyDate t(*this);
		++(*this);
		return t;
	}
	MyDate operator+(int n) 
	{
		if(!IsValid())
			return *this;
		MyDate t(*this);
		for(int i=0;i<n;i++)
			t++;
		return t;
	}
	friend ostream& operator<<(ostream& os,MyDate d);
};
int MyDate::mday[12]={31,28,31,30,31,30,31,31,30,31,30,31};
ostream& operator<<(ostream& os,MyDate d)
{
	if(!d.IsValid())
	{
		os<<"[#Invalid]";
		return os;
	}
	os<<d.year<<"/";
	if(d.month<10)
		os<<"0";
	os<<d.month<<"/";
	if(d.day<10)
		os<<"0";
	os<<d.day;
	return os;
}
//start
class Person
{
private:
    MyDate Bir;
    string w;
    friend ostream& operator<<(ostream& os,Person a);
public:
    Person(string q,int a=-1,int b=-1,int c=-1)
    {
        w=q;
        MyDate w(a,b,c);
        Bir=w;
    }
    string GetName()
    {
        return w; 
    }
    bool operator==(Person a)
    {   
        if(w==a.w&&Bir==a.Bir)
        { 
          return true;
        }
        else
        { 
          return false;
        }
    }
    bool operator<(Person a)
    {
        if(Bir<a.Bir)
          return true;
        else
          return false;
    }
    bool operator>(Person a)
    {
        if(Bir<a.Bir||Bir==a.Bir)
           return false;
        else
           return true;
    }
};
ostream& operator<<(ostream& os,Person a)
{
    cout<<a.w<<","<<a.Bir<<"��";
    return os;
}
//end
int main()
{
	char s1[100],s2[100];
	int a,b,c,x,y,z;
	cin>>s1>>a>>b>>c;
	cin>>s2>>x>>y>>z;
	Person p1(s1,a,b,c),p2(s2,x,y,z);
	cout<<p1<<endl;
	cout<<p2<<endl;
	if(p1==p2)
		cout<<"����ͬһ����\n";
	else if(p1<p2)
		cout<<"�곤�ߣ�"<<p1.GetName()<<endl;
	else if(p1>p2)
		cout<<"�곤�ߣ�"<<p2.GetName()<<endl;
	else
		cout<<"����������ͬ\n";
	return 0;
}
