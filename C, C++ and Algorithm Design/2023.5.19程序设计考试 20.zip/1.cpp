#include <iostream>
using namespace std;
class Sub
{
private:
    int ds;
public:
    Sub(int x=0)
    {
		ds=x;
	}
	void Show()
	{
		cout<<"Sub="<<ds<<endl;
	}
	void Inc()
	{
		ds++;
	}
};
class Box
{
private:
	Sub da;
	double db;
public:
//start
    Box(int x,double y)
    {
        Sub w(x);
        da=w;
        db=y;
    }
    void Inc()
    {
        db+=1;
        da.Inc();
    }
    void Show()
    {
        da.Show();
        cout<<"Box="<<db<<endl;
    }
//end
};
int main()
{
	int a;
	double b;
    cout.precision(3);
    cout<<fixed;
	cin>>a>>b;
	Box x(a,b);
	x.Show();
	x.Inc();
	x.Show();
	return 0;
}
