#include <iostream>
using namespace std;
class MyDate
{private:
    int year,month,day;
    static int mday[12];
public:
    MyDate(int a=-1,int b=-1,int c=-1):year(a),month(b),day(c)
    {
    	if(!IsValid())
			year=month=day=-1;
	}
	bool IsValid()
	{
		if(year<1 || year>9999 || month<1 || month>12)
			return false;
		int k=mday[month-1];
		if(month==2 && IsLeap())
			k=29;
		return day>0 && day<=k;
	}
	bool IsLeap()
	{
		return year%400==0 || year%4==0 && year%100!=0 ;
	}
	bool operator==(MyDate d2)
	{
		int t1=year*10000+month*100+day;
		int t2=d2.year*10000+d2.month*100+d2.day;
		if(!IsValid())
			t1=-1;
		return t1==t2;
	}
	bool operator<(MyDate d2)
	{
		int t1=year*10000+month*100+day;
		int t2=d2.year*10000+d2.month*100+d2.day;
		return t1<t2; 
	}
	MyDate& operator++()		//++ǰ�� 
	{
		day++;
		if(!IsValid())
		{
			day=1;
			month++;
			if(month>12)
			{
				month=1;
				year++;
			}
		}
		return *this;
	}
	MyDate operator++(int)	//����++ 
	{
		MyDate t(*this);
		++(*this);
		return t;
	}
	friend ostream& operator<<(ostream& os,MyDate d);
};
int MyDate::mday[12]={31,28,31,30,31,30,31,31,30,31,30,31};
ostream& operator<<(ostream& os,MyDate d)
{
	if(!d.IsValid())
	{
		os<<"[#Invalid]";
		return os;
	}
	os<<d.year<<"/";
	if(d.month<10)
		os<<"0";
	os<<d.month<<"/";
	if(d.day<10)
		os<<"0";
	os<<d.day;
	return os;
}
class MyClock
{
private:
    int tm;
public:
	MyClock(int h=0,int m=0,int s=0)
	{
		if(h<0||h>23||m<0||m>59||s<0||s>59)
			tm=0;
		else
			tm=h*3600+m*60+s;
	}
	MyClock operator+(int n)
	{
		MyClock x;
		x.tm=(tm+n)%86400;
		if(x.tm<0)
			x.tm+=86400;
		return x;
	}
	int operator[](int k)
	{
		if(k==1)
			return tm/3600;
		if(k==2)
			return tm/60%60;
		if(k==3)
			return tm%60;
		throw("Invalid [?] of MyClock.");
	}
	bool operator<(MyClock t)
	{	return tm<t.tm;	}
	bool operator==(MyClock t)
	{	return tm==t.tm;	}
	friend istream& operator>>(istream& is,MyClock &t);
	friend ostream& operator<<(ostream& os,MyClock &t);
};
istream& operator>>(istream& is,MyClock &t)
{
	int a,b,c;
	is>>a>>b>>c;
	if(a<0||a>23||b<0||b>59||c<0||c>59)
		return is;
	t.tm=a*3600+b*60+c;
	return is;
}
ostream& operator<<(ostream& os,MyClock &t)
{
	int h,m,s;
	h=t.tm/3600;
	m=t.tm/60%60;
	s=t.tm%60;
	if(h<10)
		os<<"0";
	os<<h<<":";
	if(m<10)
		os<<"0";
	os<<m<<":";
	if(s<10)
		os<<"0";
	os<<s;
	return os;
}
class Time
{
private:
	MyDate sdate;
	MyClock stime;
//start
public:
    friend ostream& operator<<(ostream& os,Time a);
    Time(int a,int b=-1,int c=-1,int d=0,int e=0,int f=0)
    {
        MyDate x(a,b,c);
        sdate=x;
        MyClock y(d,e,f);
        stime=y;
    }
    Time()
    {
        MyDate x;
        sdate=x;
        MyClock y;
        stime=y;
    }
    bool operator==(Time a)
    {
        if(sdate==a.sdate&&stime==a.stime)
          return true;
        else
          return false;
    }
    bool operator<(Time a)
    {
        if(sdate<a.sdate)
          return true;
        else if(sdate==a.sdate&&stime<a.stime)
                return true;
             else
                return false;
    }
    Time operator+(int a)
    { 
        Time w;
        w.sdate=sdate;
        w.stime=stime;
        int i;
        for(i=0;i<a;i++)
            ++w.sdate;
        return w;
    }
    Time operator+(MyClock a)
    {     
        int o=a[1]*3600+a[2]*60+a[3];
        Time w;
        w.sdate=sdate;
        int W=stime[1]*3600+stime[2]*60+stime[3]+o;
        if(W>=86400)
        {
            for(int i=0;i<W/86400;i++)
               ++w.sdate;
        }
        w.stime=stime+o;
        return w;
    }
     
};
ostream& operator<<(ostream& os,Time a)
{
    cout<<"["<<a.sdate<<"]"<<a.stime;
    return os;
}
//end
int main()
{
	int y1,m1,d1,h1,mn1,s1,y2,m2,d2,h2,mn2,s2;
	cin>>y1>>m1>>d1>>h1>>mn1>>s1;
	cin>>y2>>m2>>d2>>h2>>mn2>>s2;
	Time t1(y1,m1,d1,h1,mn1,s1),t2(y2,m2,d2,h2,mn2,s2),t3;
	if(t1<t2)
	{
		MyClock dd(h2,mn2,s2);
		t3=t1+dd;
    	cout<<"t1:"<<t1<<endl;
    	cout<<"t2:"<<t2<<endl;
    	cout<<"t3:"<<t3<<endl;
	}
	else if(t1==t2)
	{
		cout<<"same.\n"<<t1<<endl;
	}
	else
	{
		t3=t2+d1;
        cout<<"t1="<<t1<<endl;
    	cout<<"t2="<<t2<<endl;
    	cout<<"t3="<<t3<<endl;
	}
	return 0;
}
