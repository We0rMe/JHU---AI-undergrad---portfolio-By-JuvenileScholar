#include <iostream>
using namespace std;
class Father
{
protected:
    int x,y;
public:
    Father(int a, int b):x(a),y(b)
	{	}
	bool IsValid()  //It's ture only when x>0 and y>0
	{
		return x>0 && y>0;
	}
    void Show()
	{
		printf("%d,%d",x,y);
	}
	virtual void Move(int a,int b)	//Modify attribute relatively from current values
	{
		x+=a;
		y+=b;
	}
};
class Son : public Father
{
protected:
    int z;
public:
//start
    Son(int a,int b,int c):Father(a,b),z(c)
    { }
    bool IsValid()
    {
        return x>0&&y>0&&z>0;
    }
    void Move(int a,int b,int c)
    {
        x+=a;
        y+=b;
        z+=c;
    }
    virtual void Show()
    {
        printf("%d,%d,%d",x,y,z);
    }
//end
};	//end of class Son
int main()
{
    int a,b,c;
	cin>>a>>b>>c;
	Father F(a,b);
	Son S(c,a,b);
	F.Move(-3,-7);
	S.Move(-7,-3,-5);
	if(F.IsValid())
	{
		F.Show();
		cout<<endl;
	}
	else
		cout<<"F Invalid\n";
	if(S.IsValid())
	{
		S.Father::Show();
		cout<<endl;
		S.Show();
		cout<<endl;
	}
	else
		cout<<"S Invalid\n";
	return 0;
}
