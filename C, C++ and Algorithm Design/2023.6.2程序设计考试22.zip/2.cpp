#include <iostream>
#include <set>
#include <list>
#include <map>
using namespace std;
class Fx
{private:
    set<int> sx;
	int sd1,sd2;
public:
	Fx(int a,int b):sd1(a),sd2(b)
	{	}
	void ins(int x)
	{
		x=(x*sd1+sd2)%100;
		swap(sd1,sd2);
		sx.insert(x);
	}
	int count()
	{	return sx.size();	}
	void show(int n)
	{
		set<int>::iterator q;
		int i;
		if(n<=0 || n>sx.size())
			return ;
		for(i=1,q=sx.begin();i<n/2;i++,q++)
			i=i;
		cout<<*q;
	}
};
class Fun:public Fx
{protected:
	list<int> sy;
public:
	Fun(int a,int b):Fx(a,b)
	{	}
	void ins(int x)
	{
		int k=Fx::count();
		Fx::ins(x);
		if(k<Fx::count())
			sy.push_back(x);
	}
	int count()
	{	return sy.size();	}
	void show(int n)
	{
		list<int>::iterator q;
		int i;
		if(n<=0 || n>Fx::count()+sy.size())
			return ;
		if(n<=Fx::count())
			Fx::show(n);
		else
		{
			n-=Fx::count();
			for(i=1,q=sy.begin();i<n;q++);
			cout<<*q;
		}
	}
};
class Funny:public Fun
{protected:
	map<int,int> sz;
public:
	Funny(int a=2041,int b=1973):Fun(a,b)
	{	}
	void ins(int x)
	{
		int k=Fx::count();
		Fun::ins(x);
		if(k<Fx::count())
			sz[x]++;
	}
	int count(int n)
	{	return sz[n];	}
	void show(int n)
	{
		if(sz.find(n)!=sz.end())
			cout<<sz[n]<<endl;
		else
		{
			Fun::show(n);
			cout<<endl;
		}
	}
};
int main()
{
	int i,k,n,x;
	Funny t;
//start
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>k;
        t.ins(k);
    }    
    k=t.Fx::count();
    cout<<k<<endl;
    t.Fx::show(k);
    cout<<endl;
    
    k=t.Fun::count();
    cout<<k<<endl;
    t.Fun::show(k);
    cout<<endl;
    
    k=t.count(n);
    cout<<k<<endl;
    t.show(k);
    cout<<endl;
//end
}
