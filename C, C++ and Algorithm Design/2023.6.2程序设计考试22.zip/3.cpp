#include <iostream>
#include <string>
using namespace std;
class MyDate
{
protected:
    int year,month,day;
    static int days[12];
public:
    MyDate(int y=-1, int m=1, int d=1):year(y),month(m),day(d)
	{
		if(!IsValid())
			year=month=day=-1;
	}
	bool LeapYear( )
	{
		if(!IsValid())
			return false;
		return (year%400==0 || year%4==0 && year%100);
	}
    bool IsValid(void)  //�ж�һ�������յ�ֵ�Ƿ�����Ч����
    {
		if(year<=0 || year>9999 || month<1 || month>12)
			return false;
		int k=month==2 && (year%400==0 || year%4==0 && year%100);
		if(day>0 && day<=days[month-1]+k)
			return true;
		else
			return false;
	}
	int operator[](int k)
	{
        if(!IsValid()||k<1||k>3)
            return -1;
		if(k==1)
			return year;
		if(k==2)
			return month;
		if(k==3)
			return day;
		throw("Invalid [?] of Date.");
	}
	MyDate operator++()	//ǰ��++
	{
        if(!IsValid())
            return *this;
		day++;
		if(!IsValid())
			month++,day=1;
		if(!IsValid())
			year++,month=1;
		return *this;
	}
	MyDate operator--()	//ǰ��--
	{
        if(!IsValid())
            return *this;
		day--;
		if(day<=0)
		{
			month--,day=31;
			if(month<0)
				year--,month=12;
			else
				while(!IsValid())
					day--;
		}
		return *this;
	}
	MyDate operator+(int d)	//��dd��֮������ڣ�dd�����ɸ�
	{
        if(!IsValid()||d==0)
            return *this;
		MyDate tmp(*this);
		if(d>0)
		{
			while(d>0)
			{
				++tmp;
				d--;
			}
		}
		else
		{
			while(d<0)
			{
				--tmp;
				d++;
			}
		}
		return tmp;
	}
	bool operator<(MyDate y)
	{
        if(!IsValid() || !y.IsValid())
            return false;
		return (year<y.year
			|| year==y.year && month<y.month
			|| year==y.year && month==y.month && day<y.day);
	}
	virtual bool operator==(MyDate y)
	{
        if(!IsValid() || !y.IsValid())
            return false;
		return (year==y.year && month==y.month && day==y.day);
	}
	virtual string ToString()
	{
		string s;
		int y=year,m=month,d=day,t=1000;
		if(!IsValid())
			return "[Invalid date]";
		for(int i=0;i<4;i++)
			s=s+char(y/t+48),y%=t,t/=10;
		s=s+"/";
		if(m>9)
			s=s+char(m/10+48),m%=10;
		s=s+char(m+48);
		s=s+"/";
		if(d>9)
			s=s+char(d/10+48),d%=10;
		s=s+char(d+48);
		return s;
	}
};
int MyDate::days[12]={31,28,31,30,31,30,31,31,30,31,30,31};
class WDate:public MyDate
{
public:
//start
    WDate(int a,int b,int c):MyDate(a,b,c)
    {  }
    WDate():MyDate()
    {  }
    int WeekDay()
    { 
        if(!MyDate::IsValid())
        {
            return -1;
        }
        else
        {
            int k=(day+2*month+3*(month+1)/5+year+year/4-year/100+year/400)%7;
            switch(k)
            {
                case 1: return 2;
                case 2: return 3;
                case 3: return 4;
                case 4: return 5;
                case 5: return 6;
                case 6: return 0;
                case 0: return 1;
                default:
                   cout<<k;
            }     
	    }
	}
    string ToString()
    {
        if(MyDate::IsValid())
        {   
            switch(WeekDay())
            {
                case 0:
                   return MyDate::ToString()+"(Sun)";
                case 1:
                   return MyDate::ToString()+"(Mon)";
                case 2:
                   return MyDate::ToString()+"(Tue)";
                case 3:
                   return MyDate::ToString()+"(Wed)";
                case 4:
                   return MyDate::ToString()+"(Thu)";
                case 5:
                   return MyDate::ToString()+"(Fri)";
                case 6:
                   return MyDate::ToString()+"(Sat)";
            }
        }
        else
            return "[Invalid date]";
    }
    bool operator<(WDate a)
    {
        MyDate w(a.MyDate::operator[](1),a.MyDate::operator[](2),a.MyDate::operator[](3));
        MyDate q((*this).MyDate::operator[](1),(*this).MyDate::operator[](2),(*this).MyDate::operator[](3));
        return q<w;
    }
    WDate operator+(int a)
    {   
            WDate w;
            w=*this;
            MyDate q;
            q=w.MyDate::operator+(a);
            return WDate(q[1],q[2],q[3]);
    }
    WDate operator=(WDate a)
    {
        MyDate::year=a.MyDate::year;
        MyDate::month=a.MyDate::month;
        MyDate::day=a.MyDate::day;
        return *this;
    }
//end
};
int main()
{
	int y1,m1,d1,y2,m2,d2;
	cin>>y1>>m1>>d1;
	cin>>y2>>m2>>d2;
	WDate t1(y1,m1,d1),t2(y2,m2,d2),t3;
	if(t1<t2)
	{
		cout<<"t1<t2\n";
		t3=t1+y2%517;
	}
	else if(t1==t2)
	{
		cout<<"t1==t2\n";
	}
	else
	{
		cout<<"t1>t2\n";
		t3=t2+y1%1021;
	}
	cout<<"t1="<<t1.ToString()<<","<<t1.WeekDay()<<endl;
	cout<<"t2="<<t2.ToString()<<","<<t2.WeekDay()<<endl;
	cout<<"t3="<<t3.MyDate::ToString()<<","<<t3.WeekDay()<<endl;
	return 0;
}
