#include <iostream>
using namespace std;
int prime(int a)
{
    int flat=1,j;
    if(a==1)
       flat=0;
    else if(a==2)
       flat=1;
    else
    {  for(j=2;j<a;j++)
    { 
        if(a%j==0)
        { 
           flat=0;
           break;
        }
        else
           flat=1;                   
    }
    }
    return flat;
}
int main()
{
    int n,i,y=0;
    cin>>n;
    for(i=2;i<=n;i++)
    {
        if(n%i==0&&prime(i))
           y++;
    }
    cout<<y;
}
