#include <iostream>
using namespace std;
int main()
{
    int n,i,y,x,m=0;
    cin>>n;
    for(i=1;i<=n-8;i++)
       for(y=1;y<=n-12;y++)
          for(x=1;x<=n-10;x++)
          {
              if(7*i+3*y+5*x==n)
                 m++;
          }
    cout<<m;
}
