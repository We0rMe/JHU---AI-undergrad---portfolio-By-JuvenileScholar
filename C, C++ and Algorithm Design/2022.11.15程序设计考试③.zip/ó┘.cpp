#include <iostream>
using namespace std;
int main()
{
    int a,b,i,j,s,m;
    cin>>a>>b;
    if(a==b)
       cout<<"No";
    else
    {  for(i=1;i<a;i++)
    {
        if(a%i==0)
           s+=i;        
    }
    for(j=1;j<b;j++)
    {
        if(b%j==0)
           m+=j;
    }
    if(s==b&&m==a)
       cout<<"Yes";
    else
       cout<<"No";
}
}
