#include <iostream>
using namespace std;
int main()
{   
    int N,a,b,c,i,t,max,min;
    int s=0; 
    cin>>N;
    if(N<100||N>999)
       cout<<N<<":"<<"Error";
    else
    {
        a=N%10;
        b=(N%100)/10;
        c=N/100;
        if(a==b&&a==c)
           cout<<N<<":"<<"Impossible";
        else
        {
            for(i=N;i!=495;s++)
            {
                a=i%10,b=i/10%10,c=i/100;
                if(c>b)
                   t=c,c=b,b=t;
                if(b>a)
                   t=b,b=a,a=t;
                if(c>b)
                   t=c,c=b,b=t;
                max=a*100+b*10+c;
                min=c*100+b*10+a;
                i=max-min;
            }
            cout<<N<<":"<<s;
        }
        
    }
}
