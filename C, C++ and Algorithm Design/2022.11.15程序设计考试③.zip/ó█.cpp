#include <iostream>
using namespace std;
int PDD(int a)
{
    int i,w;
    if(a==1)
       w=0;
    else if(a==2)
       w=1;
    else
    {
        for(i=2;i<a;i++)
        {
            if(a%i==0)
            {
                w=0;
                break;
            }
            else
                w=1;
        }
    }
    return w;
}
int main()
{
    int y,m=0,b,c;
    cin>>b>>c;
    if(b==c&&PDD(b)==1&&PDD(c)==1)
       cout<<"1";
    else  if(b==c)
       cout<<"0";
    else 
    {
      if(b>c)
      swap(b,c);
    for(y=b;y<=c;y++)
    {
        if(PDD(y)==1)
           m++;
    }
    cout<<m;
    }
}
