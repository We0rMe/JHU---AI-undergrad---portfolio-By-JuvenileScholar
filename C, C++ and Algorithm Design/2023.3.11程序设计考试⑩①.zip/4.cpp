#include <iostream>
using namespace std;
//start
struct date
{
    int year,month,day;
};
template <class T>
void MSort(T *x,int a,int b)
{
    
    for(int i=1;i<=b;i++)
       for(int j=0;j<b-i+1;j++)
       {
           if(*(x+j)>*(x+j+1))
        {
            swap(*(x+j),*(x+j+1));
        }
       }
}
void MSort(struct date *x,int a,int b)
{
    struct date c;
    for(int i=1;i<=b;i++)
       for(int j=0;j<b-i+1;j++)
          if((*(x+j)).year>(*(x+j+1)).year)
             swap(*(x+j),*(x+j+1));
}
//end
int main()
{
	int k;
	char bufc[]="Object-oriented Programming.";
	int bufi[]={29,43,17,66,72,19,30,15,35};
	double buff[]={17.9,5.1,32.45,0,-6.57,0.317,-2.1794,8.4};
	struct date bufd[]={1988,3,5,2000,5,20,1999,12,31,2003,10,12,2010,4,5,2002,7,3};
	cin>>k;
	if(k==0)
	{
		MSort(bufc,0,27);
		cout<<bufc+1;
	}
	if(k==1)
	{
		MSort(bufi,0,8);
		cout<<bufi[1]<<','<<bufi[7];
	}
	if(k==2)
	{
		MSort(buff,0,7);
		cout<<buff[1]<<','<<buff[6];
	}
	if(k==3)
	{
		MSort(bufd,0,5);
		cout<<bufd[3].year<<'-'<<bufd[3].month<<'-'<<bufd[3].day;
	}
	return 0;
}
