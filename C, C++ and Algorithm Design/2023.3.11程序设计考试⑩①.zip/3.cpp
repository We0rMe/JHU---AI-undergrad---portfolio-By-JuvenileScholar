#include <iostream>
#include <stdlib.h>
using namespace std;
//start
struct Date
{
  int year,month,day;  
};
struct Time
{
  int hour,minute;  
};
void Show(char *p,int n)
{
    cout<<p;
    cout<<endl;
}
void Show(int *p,int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<fixed;
        cout.width(5);
        cout<<*(p+i);
    }
    cout<<endl;
}
void Show(double *p,int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<fixed;
        cout.width(5);
        cout.precision(1);
        cout<<*(p+i);
    }
    cout<<endl;

}
void Show(struct Date *p,int n)
{   for(int i=0;i<n;i++)
    {
    cout<<fixed;
    cout<<(*(p+i)).year<<'/';
    if((*(p+i)).month<10)
      cout<<0<<(*(p+i)).month<<'/';
    else
      cout<<(*(p+i)).month<<'/';
    if((*(p+i)).day<10)
      cout<<0<<(*(p+i)).day<<' ';
    else
      cout<<(*(p+i)).day<<' ';
    
    }
    cout<<endl;
}
void Show(struct Time *p,int n)
{
    for(int i=0;i<n;i++)
    {
       if((*(p+i)).hour<10)
         cout<<0<<(*(p+i)).hour<<':';
       else
         cout<<(*(p+i)).hour<<':';
       if((*(p+i)).minute<10)
         cout<<0<<(*(p+i)).minute<<' ';
       else
         cout<<(*(p+i)).minute<<' ';
     
    }
    cout<<endl;
}
//end
int main()
{
	int i,k;
	char x1[100]={0};
	int x2[100];
	double x3[100];
	Date x4[100];
	Time x5[100];
    cout<<fixed;
    cout.precision(1);
	cin>>k;
	srand(k);
	for(i=0;i<k;i++)
	{
		x1[i]='A'+rand()%26;
		x2[i]=rand()%100;
		x3[i]=rand()/427.3;
		x4[i].year=rand()%20+2000;
		x4[i].month=rand()%12+1;
		x4[i].day=rand()%30+1;
		x5[i].hour=rand()%24;
		x5[i].minute=rand()%50;
	}
	if(k>5)
		k=5;
	Show(x1,k);
	Show(x2,k);
	Show(x3,k);
	Show(x4,k);
	Show(x5,k);
	return 0;
}
