#include <iostream>
#include <stdlib.h>
using namespace std;
struct Point
{    double x,y;
};
//start
template <class T>
void Echg(T &a,T &b)
{
    swap(a,b);
}
template <class T>
void Echg(T &a,T &b,T &c)
{
    T w=c;
    c=a;
    a=b;
    b=w;
}
template <class T>
void Echg(T &a,T &b,T &c,T &d)
{
    T w;
    w=a;
    a=b;
    b=c;
    c=d;
    d=w;
}
//end
int main()
{
	int a,b,c,d;
	Point p1,p2;
	cin>>a>>b>>c>>d>>p1.x>>p1.y>>p2.x>>p2.y;
	Echg(a,b);
	Echg(b,c,d);
	Echg(p2,p1);
	Echg(p1.x,p1.y,p2.x,p2.y);
	cout<<a<<","<<b<<","<<c<<","<<d<<endl;
	cout<<"("<<p1.x<<","<<p1.y<<")\n";
	cout<<"("<<p2.x<<","<<p2.y<<")\n";
}
