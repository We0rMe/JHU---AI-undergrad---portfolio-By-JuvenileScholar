#include <iostream>
using namespace std;
//start
struct Date
{
  int year,month,day;  
};
template <class T>
void Reverse(T *p,int a,int b)
{   T w[b+1];
    int i;
    if(a>=b)
      ;
    else
    {
        for(i=a;i<=b;i++)
            w[i]=*(p+i);
        for(i=a;i<=b;i++)
            *(p+i)=w[b+a-i];
    }
}
//end
int main()
{
	int i,k;
	char bufc[]="Object-oriented Programming.";
	int bufi[]={29,43,17,66,72,19,30,15,35};
	double buff[]={17.9,5.1,32.45,0,-6.57,0.317,-2.1794,8.4};
	struct Date bufd[]={1988,3,5,2000,5,20,1999,12,31,2003,10,12,2010,4,5,2002,7,3};
	cin>>k;
    cout<<k<<endl;
	Reverse(bufc,0,k);
	cout<<bufc<<endl;
	Reverse(bufi,0,k-1);
    cout<<bufi[0]<<','<<bufi[k/2]<<endl;
	Reverse(buff,1,7-k);
	cout<<buff[2]<<','<<buff[k/2]<<endl;
	Reverse(bufd,0,5-k);
	cout<<bufd[k/2].year<<'-'<<bufd[k/2].month<<'-'<<bufd[k/2].day<<endl;
	return 0;
}
