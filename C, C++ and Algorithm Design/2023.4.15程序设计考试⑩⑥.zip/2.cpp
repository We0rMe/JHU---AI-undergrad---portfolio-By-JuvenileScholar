#include <iostream>
#include <stdlib.h>
using namespace std;
//start
class MyClock
{
  private:
    int h,m,s;
  public:
    MyClock()
    {
        h=0,m=0,s=0;
    }
    MyClock(int a)
    {   if(a>86399)
        {
            h=0,m=0,s=0;
        }
        else
        {
        h=a/3600;
        m=(a%3600)/60;
        s=(a%3600)%60;
        }
    }
    MyClock(int a,int b,int c=0)
    {   if(a<1&&a>24||b<1&&b>60||c<1&&c>60)
        {
            h=0,m=0,s=0;
        }
        else
        {
        h=a;
        m=b;
        s=c;
        }
    }
    void Set()
    {
        h=0,m=0,s=0;
    }
    void Set(int a)
    {   if(a>86399)
        {
            h=0,m=0,s=0;
        }
        else
        {
        h=a/3600;
        m=(a%3600)/60;
        s=(a%3600)%60;
        }
    }
    void Set(int a,int b,int c=0)
    {
        if(a<1&&a>24||b<1&&b>60||c<1&&c>60)
        {
            h=0,m=0,s=0;
        }
        else
        {
            h=a;
            m=b;
            s=c;
        }
    }
    void Show()
    {
        if(h<10)
          cout<<"0";
        cout<<h<<":";
        if(m<10)
          cout<<"0";
        cout<<m<<":";
        if(s<10)
          cout<<"0";
        cout<<s;
    }
    bool operator==(MyClock a)
    {
        if(h==a.h&&m==a.m&&s==a.s)
          return true;
        else
          return false;
    }
    bool operator<(MyClock a)
    {
        if(h<a.h)
          return true;
        else if(h==a.h)
             {
                 if(m<a.m)
                   return true;
                 else if(m==a.m)
                      {
                          if(s<a.s)
                            return true;
                          else
                            return false; 
                      }
                      else
                        return false;
             }
             return false;
    }
    
};
//end
int main()
{
	int i,j,n;
	cin>>n;
	srand(n);
	MyClock ck[1000];
	for(i=0;i<n;i++)
		ck[i].Set(rand()%86400);
    for(i=1;i<n;i++)
		for(j=0;j<n-i;j++)
			if(!(ck[j]<ck[j+1]))
				swap(ck[j],ck[j+1]);
	cout<<n<<" random clock:\n";
	ck[0].Show();
	cout<<" ... ";
	ck[n-1].Show();
	for(i=0;i<n-1;i++)
		if(ck[i]==ck[i+1])
			break;
	cout<<(i<n-1?"\n====":"\nXXXX");
}
