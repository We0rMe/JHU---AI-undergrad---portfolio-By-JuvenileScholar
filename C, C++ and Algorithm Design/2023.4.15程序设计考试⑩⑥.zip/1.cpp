#include <iostream>
#include <stdlib.h>
#include <algorithm>
using namespace std;
//start
class MyDate
{
  private:
    int y,m,d;
  public:
    MyDate(int a,int b=1,int c=1)
    {   if(a<1||b<1&&b>12||c<1&&c>31)
        {
            y=-1,m=-1,d=-1;
        }
        else
        {
            y=a;
            m=b;
            d=c;
        }
    }
    void Show()
    {
        if(y==-1||m==-1||d==-1)
        {
            cout<<"[#Invalid]";
        }
        else
        {
            if(y<10)
              cout<<"000";
            if(y<100)
              cout<<"00";
            if(y<1000)
              cout<<"0";
            cout<<y<<"/";
            if(m<10)
              cout<<"0";
            cout<<m<<"/";
            if(d<10)
              cout<<"0";
            cout<<d;
        }
    }
    bool IsValid()
    {
        if(y==-1||m==-1||d==-1)
          return false;
        else
          return true;
    }
    bool operator==(MyDate a)
    {
        if(y==-1||m==-1||d==-1||a.y==-1||a.m==-1||a.d==-1)
          return false;
        else if(y==a.y&&m==a.m&&d==a.d)
              return true;
             else
              return false;
    }
    bool operator<(MyDate a)
    {
        if(y==-1&&a.y!=-1)
          return true;
        else if(y!=-1&&a.y!=-1)
        {
        if(y<a.y)
          return true;
        else if(y==a.y)
             {
                 if(m<a.m)
                   return true;
                 else if(m==a.m)
                      {
                          if(d<a.d)
                            return true;
                          else 
                            return false;
                      }
                      else
                        return false;
             }
             else
               return false;
        }       
    }
};
//end
int main()
{
	int k,y,m,d;
	cin>>k>>y>>m>>d;
	srand(k);
	MyDate d1(rand()%100+1950,rand()%12+1,rand()%30),d2(y,m,d);
	d1.Show();
	if(d1<d2)
		cout<<" << ";
	else if(d1==d2)
		cout<<" == ";
	else
		cout<<" >> ";
	d2.Show();
}
