#include <iostream>
#include <math.h>
using namespace std;
//start
class MyComplex
{
  private:
    double real,imag;
    static double delta;
  public:
    MyComplex()
    {
        real=0;
        imag=0;
    }
    MyComplex(double a,double b=0)
    {
        real=a;
        imag=b;
    }
    void Show()
    {   cout<<fixed;
        cout.precision(3);
        if(imag==0)
          cout<<real;
        else
        {
            if(imag<0)
              cout<<"("<<real<<imag<<"i)";
            else if(imag>0)
                   cout<<"("<<real<<"+"<<imag<<"i)";
        }
    }
    bool operator==(MyComplex a)
    {
        if(fabs(real-a.real)<delta&&fabs(imag-a.imag)<delta)
          return true;
        else
          return false;
    }
    MyComplex operator+(MyComplex a)
    {   double x,y;
        x=real+a.real;
        y=imag+a.imag;
        return MyComplex(x,y);
    }
    MyComplex operator-(MyComplex a)
    {   double x,y;
        x=real-a.real;
        y=imag-a.imag;
        return MyComplex(x,y);
    }
    MyComplex operator*(MyComplex a)
    {  double x,y;
        x=real*a.real-imag*a.imag;
        y=imag*a.real+real*a.imag;
        return MyComplex(x,y);
    }
    MyComplex operator/(MyComplex a)
    {   double x,y;
        if(a.real==0&&a.imag==0)
        {
            cout<<"Divided by 0."<<endl;
            return MyComplex(0,0);
        }
        else
        {
            x=(real*a.real+imag*a.imag)/(a.real*a.real+a.imag*a.imag);
            y=(imag*a.real-real*a.imag)/(a.real*a.real+a.imag*a.imag);
            return MyComplex(x,y);
        }
    }
};
double MyComplex::delta=0.00001;
//end
int main()
{
	double a,b,c,d;
	cin>>a>>b>>c>>d;
	cout.precision(3);
	cout<<fixed;
	MyComplex x(a,b),y(c,d),z(0,0);
	cout<<"ADD : ";
	z=x+y;
	z.Show();
	cout<<"\nSUB : ";
	z=x-y;
	z.Show();
	cout<<"\nMUL : ";
	z=x*y;
	z.Show();
	cout<<"\nDIV : ";
	z=x/y;
	z.Show();
	return 0;
}
