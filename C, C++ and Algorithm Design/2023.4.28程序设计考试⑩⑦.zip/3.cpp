#include <iostream>
#include <stdlib.h>
#include <algorithm>
using namespace std;
//start
/*"�ڴ˱�дMyDate��*/
class MyDate
{
  private:
    int x,y,z;
    friend bool operator==(MyDate& a,MyDate& b);
    friend bool operator<(MyDate& a,MyDate& b);
    friend istream& operator>>(istream& is,MyDate& a);
    friend ostream& operator<<(ostream& os,MyDate& a);
  public:
    MyDate(int a,int b=1,int c=1)
    {
        if(b>12||b<=0||c>31||c<=0||(a%400==0&&b==2&&c>29)||(a%400!=0&&b==2&&c>28)||(b==4&&b==6&&b==9&&b==11&&c>30))
        {
            x=y=z=-1;
        }
        else
        {
            x=a;y=b;z=c;
        }
    }
    bool IsValid()
    {
        if(x==-1)
          return 0;
        else
          return 1;
    }
};
istream& operator>>(istream& is,MyDate& a)
{
    int x,y=1,z=1;
    is>>x>>y>>z;
    MyDate b(x,y,z);
    a.x=b.x;
    a.y=b.y;
    a.z=b.z;
    return is;
}
ostream& operator<<(ostream& os,MyDate& a)
{   if(a.IsValid())
    {
       os<<a.x<<"/";
       if(a.y<10)
          cout<<0;
       cout<<a.y<<"/";
       if(a.z<10)
          cout<<0;
       cout<<a.z;
       return os;
    }
    else
       cout<<"[#Invalid]";
}
bool operator==(MyDate& a,MyDate& b)
{
    if(!a.IsValid()||!b.IsValid())
    {
        return false;
    }
    else if(a.x==b.x&&a.y==b.y&&a.z==b.z)
         {
             return true;
         }
         else 
             return false;
}
bool operator<(MyDate& a,MyDate& b)
{
    if(!a.IsValid()&&b.IsValid())
      return true;
    else if(a.IsValid()&&b.IsValid()&&a.x<b.x)
            return true;
         else if(a.IsValid()&&b.IsValid()&&a.x==b.x&&a.y<b.y)
                 return true;
              else if(a.IsValid()&&b.IsValid()&&a.x==b.x&&a.y==b.y&&a.z<b.z)
                      return true;
                   else
                      return false;
         
}
//end
int main()
{
	int k;
	cin>>k;
	srand(k);
	MyDate d1(rand()%100+1950,rand()%13,rand()%32),d2(2000);
	cin>>d2;
	if(operator<(d1,d2))
		cout<<d1<<" < "<<d2<<endl;
	else if(operator==(d1,d2))
		cout<<d1<<" = "<<d2<<endl;
	else
		cout<<d1<<" > "<<d2<<endl;
}
