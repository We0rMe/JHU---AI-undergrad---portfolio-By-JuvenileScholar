#include <iostream>
#include <math.h>
using namespace std;
//start
class MyPoint
{
  private:
    double x,y;
    friend ostream& operator<<(ostream& b,MyPoint a);
    friend istream& operator>>(istream& is,MyPoint& a);
  public:
    MyPoint()
    {
        x=0;
        y=0;
    }
    MyPoint(double a,double b=0)
    {
        x=a;
        y=b;
    }
    double DistanceTo(MyPoint a)
    {
        return sqrt((x-a.x)*(x-a.x)+(y-a.y)*(y-a.y));
    }
    
};
ostream& operator<<(ostream& b,MyPoint a)
{
    cout<<fixed;
    cout.precision(1);
    cout<<"("<<a.x;
    cout<<',';
    cout<<a.y;
    cout<<")";
    return b;
}
istream& operator>>(istream& is,MyPoint& a)
{   
    char w;
    cin>>a.x>>w>>a.y;
    return is;
}
//end
int main()
{
	cout<<fixed;
	cout.precision(1);
	MyPoint A,B;
	cin>>A>>B;
	cout<<A<<" - "<<B<<endl;
	cout<<A.DistanceTo(B);
}
