#include <iostream>
#include <math.h>
using namespace std;
//start
class MyComplex
{
  private:
    double real,imag;
    static double delta;
    friend bool operator==(MyComplex a,MyComplex b);
    friend MyComplex operator+(MyComplex a,MyComplex b);
    friend MyComplex operator-(MyComplex a,MyComplex b);
    friend MyComplex operator*(MyComplex a,MyComplex b);
    friend MyComplex operator/(MyComplex a,MyComplex b);
    friend ostream& operator<<(ostream &a,MyComplex b);
  public:
    MyComplex()
    {
        real=0;
        imag=0;
    }
    MyComplex(double a,double b=0)
    {
        real=a;
        imag=b;
    }
};
double MyComplex::delta=0.00001;
ostream& operator<<(ostream &a,MyComplex b)
{
    if(b.imag==0)
       cout<<b.real;  
    else if(b.imag>0)
            cout<<"("<<b.real<<"+"<<b.imag<<"i)";
         else 
            cout<<"("<<b.real<<b.imag<<"i)";
    return a;
}
bool operator==(MyComplex a,MyComplex b)
{
    if(fabs(a.real-b.real)<MyComplex::delta&&fabs(a.imag-b.imag)<MyComplex::delta)
    {
        return true;
    }
    else
        return false;
}
MyComplex operator+(MyComplex a,MyComplex b)
{
    double x,y;
    x=a.real+b.real;
    y=a.imag+b.imag;
    return MyComplex(x,y);
}
MyComplex operator-(MyComplex a,MyComplex b)
{
    double x,y;
    x=a.real-b.real;
    y=a.imag-b.imag;
    return MyComplex(x,y);
}
MyComplex operator*(MyComplex a,MyComplex b)
{
    double x,y;
    x=a.real*b.real-a.imag*b.imag;
    y=a.imag*b.real+a.real*b.imag;
    return MyComplex(x,y);
}
MyComplex operator/(MyComplex a,MyComplex b)
{
    double x,y;
    if(b.real==0&&b.imag==0)
    {
        cout<<"Divided by 0."<<endl;
        return MyComplex(0,0);
    }
    else
    {
        x=(a.real*b.real+a.imag*b.imag)/(b.real*b.real+b.imag*b.imag);
        y=(a.imag*b.real-a.real*b.imag)/(b.real*b.real+b.imag*b.imag);
        return MyComplex(x,y);
    }
}
//end
int main()
{
    double a,b,c,d;
	cin>>a>>b>>c>>d;
	cout.precision(3);
	cout<<fixed;
	MyComplex x(a,b),y(c,d),z(0,0);
	cout<<"ADD : "<<operator+(x,y)<<endl;
	cout<<"SUB : "<<operator-(x,y)<<endl;
	cout<<"MUL : "<<operator*(x,y)<<endl;
	cout<<"DIV : "<<operator/(x,y)<<endl;
	return 0;
}
