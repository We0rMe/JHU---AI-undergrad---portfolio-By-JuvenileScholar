#include <iostream>
using namespace std;
int main()
{
    int i,j,n;
    cin>>n;
    int x[n][n];
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            cin>>x[i][j];
    int k=1;
    for(i=0;i<n;i++)
    {   for(j=0;j<n;j++)
        {
            if(x[i][j]!=x[j][i])
              k=0;
        }
    }
    if(k==1)
       cout<<"Yes";
    else
       cout<<"No";
}
