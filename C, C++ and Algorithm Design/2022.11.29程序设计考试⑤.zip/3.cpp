#include <iostream>
using namespace std;
int main()
{
    char x[100];
    gets(x);
    int i,j,k=0,a=1;
    for(j=0;x[j]!='\0';j++)
    {
        if(x[j]-48>11)
           a=0;
    }
    for(i=0;x[i]!='\0';i++)
        k+=x[i]-48;
    if(k%9!=0)
        a=0;
    if(a==0)
      cout<<"No";
    else
      cout<<"Yes";
}
