#include <iostream>
#include <string.h>
using namespace std;
int main()
{  char a[300],b[300];
  scanf("%s",a);
  scanf("%s",b);
  int n1[300]={0},n2[300]={0},n[300]={0};
  int l1=strlen(a);
  int l2=strlen(b);
  int i;
  for(i=0;i<l1;i++)
  n1[i]=a[l1-i-1]-'0';
  for(i=0;i<l2;i++)
  n2[i]=b[l2-1-i]-'0';
  int l=l1>l2?l1:l2;
  for(i=0;i<l;i++)
  {
      n[i]+=n1[i]+n2[i];
      if(n[i]>9)
      {
        n[i]%=10;
        n[i+1]++;
      }
  }
  if(n[l]!=0)
    cout<<n[l];
  for(i=l-1;i>=0;i--)
     cout<<n[i];
}
