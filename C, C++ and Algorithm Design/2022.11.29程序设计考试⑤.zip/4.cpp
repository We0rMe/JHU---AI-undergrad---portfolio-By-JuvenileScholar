#include <iostream>
using namespace std;
int main()
{
    char x[20];
    gets(x);
    int a[17]={7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
    int i,j=1,k=0,p,o;
    for(i=0;x[i]!='\0';i++)
        ;
    if(i!=18)
       j=0;
    for(o=0;o<17;o++)
        if(11<x[o]-48)
           j=0;
    if(11<x[17]-48&&x[17]-48!=40)
        j=0;
    for(i=0;i<17;i++)
        k+=(x[i]-48)*a[i];
    p=k%11;
    if(p==0&&x[17]-48!=1)
       j=0;
    if(p==1&&x[17]-48!=0)
       j=0;
    if(p==2&&x[17]-48!=40)
       j=0;
    for(i=3;i<=10;i++)
    {
        if(p==i&&x[17]-48!=11-i+1)
           j=0;
    }
    if(j==0)
      cout<<"No";
    else
      cout<<"Yes";
}
