#include <iostream>
#include <string.h>
using namespace std;
int main()
{
    int i,j;
    char x[99],y[99];
    gets(x);
    strcpy(y,x);
    for(j=0;x[j]!='\0';j++)
        ;
    for(i=j-1;x[i]!='\0';i--)
        y[j-1-i]=x[i];
    cout<<y;
}
