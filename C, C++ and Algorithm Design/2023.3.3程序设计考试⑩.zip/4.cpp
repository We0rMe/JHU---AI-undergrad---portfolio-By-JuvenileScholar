#include <iostream>
#include <stdlib.h>
using namespace std;
//start
int func(int *a,int n,int &max,int &min)
{
	int i,j;
	j=*a;
	for(i=1;i<n;i++)
	{
		if(j>*(a+i))
		  j=*(a+i);
	}
	min=j;
	j=*a;
	for(i=1;i<n;i++)
	{
		if(j<*(a+i))
		  j=*(a+i);
	}
	max=j;
	if(min==max)
	  return 1;
	else
	  return 2;
}
//end;
int main()
{
	int x[100],i,k,n,mx,mn;
	cin>>n;
	srand(n+2);
	for(i=0;i<n;i++)
	   x[i]=rand()%n;
	k=func(x,n,mx,mn);
	if(k==1)
	  cout<<"Max=Min="<<mx<<endl;
	else
	{
		cout<<"Max="<<mx<<endl;
		cout<<"Min="<<mn<<endl;
	}
}
