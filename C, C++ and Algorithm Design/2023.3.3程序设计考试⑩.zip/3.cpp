#include <iostream>
#include <math.h>
using namespace std;
//start
struct Point
{
	double x;
	double y;
};
struct Circle
{
	struct Point P0;
	double r;
};
void ShowP(struct Point P1)
{
	cout<<fixed;
	cout.precision(3);
	cout<<'('<<P1.x<<','<<P1.y<<')';
}
void ShowC(struct Circle C1)
{
	cout<<fixed;
	cout.precision(3);
	cout<<'('<<C1.P0.x<<','<<C1.P0.y<<','<<C1.r<<')';
}
int Cross(struct Circle C0,double d,struct Point &a,struct Point &b)
{
	if(fabs(C0.P0.y-d)>C0.r)
	  return 0;
	else if(fabs(C0.P0.y-d)==C0.r)
	     {
	     	a.y=d;
	     	a.x=C0.P0.x+sqrt(C0.r*C0.r-(d-C0.P0.y)*(d-C0.P0.y));
	     	return 1;
		 }
		 else
		 {
		 	a.y=d;
		 	a.x=C0.P0.x+sqrt(C0.r*C0.r-(d-C0.P0.y)*(d-C0.P0.y));
		 	b.y=d;
		 	b.x=C0.P0.x-sqrt(C0.r*C0.r-(d-C0.P0.y)*(d-C0.P0.y));
		 	if(a.x>b.x)
		 	{
		 		swap(a.x,b.x);
		 		swap(a.y,b.y);
			}
			return 2;
		 }
}
//end
int main()
{
	cout<<fixed;
	cout.precision(3);
	double x,y,r,d;
	cin>>x>>y>>r>>d;
	Point P0={x,y},P1,P2;
	Circle C0={P0,r};
	ShowC(C0);
	cout<<endl;
	switch(Cross(C0,d,P1,P2))
	{
		case 0:
			cout<<"No intersection.\n"; break;
		case 1:
			cout<<"1 intersection:\n";
			ShowP(P1);
			cout<<endl;
			break;
		case 2:
			cout<<"2 intersections:\n";
			ShowP(P1);
			cout<<endl;
			ShowP(P2);
			cout<<endl;
	 } 
} 
