#include <iostream>
#include <math.h>
using namespace std;
//start
int findroot(double a,double b,double c,double *x,double *y)
{
   if(a==0&&b!=0)
   {
   	 *x=(-c)/b;
   	 return 1;
   }
   else if(a==0&&b==0&&c==0)
        {
        	return -1;
		}
		else if(a==0&&b==0)
		     {
		     	return 0;
			 }
			 else if(b*b-4*a*c<0||b==0&&a*c>0)
			      {
			      	return 0;
				  }
				  else if(b*b-4*a*c==0)
				       {
				       	 *x=(-b)/(2*a);
				       	 return 1;
					   }
					   else if(b*b-4*a*c>0)
					        {
					        	*x=((-b)+sqrt(b*b-4*a*c))/(2*a);
					        	*y=((-b)-sqrt(b*b-4*a*c))/(2*a);
					        	if(*x>*y)
					        	  swap(*x,*y);
					        	return 2;
							}
}
//end
int main()
{
	double a,b,c,d,x1,x2;
	cin>>a>>b>>c;
	int k;
	cout<<fixed;
	cout.precision(3);
	k=findroot(a,b,c,&x1,&x2);
	switch(k)
	{
		case -1:
			cout<<"Infinite solutions\n"; break;
		case 0:
			cout<<"No solution\n"; break;
		case 1:
			cout<<"x="<<x1<<endl; break;
		case 2:
			cout<<"x1="<<x1<<endl;
			cout<<"x2="<<x2<<endl;
			break;
		default:
		    cout<<"Return error.\n"; 
	}
	return 0;
}
